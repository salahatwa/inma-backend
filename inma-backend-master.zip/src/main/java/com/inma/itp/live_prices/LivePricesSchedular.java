package com.inma.itp.live_prices;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.inma.itp.stock.model.domain.StockInfo;
import com.inma.itp.stock.service.StockService;

@Component
public class LivePricesSchedular {

	@Autowired
	private SimpMessagingTemplate template;

	@Autowired
	private StockService stockService;

	@Scheduled(fixedRate = 5000)
	public void performTask() {

		List<StockInfo> stocks = stockService.getAllStocks().stream().limit(10).collect(Collectors.toList());

		template.convertAndSend("/topic/live-prices", stocks);

	}

}
