package com.inma.itp.config;

import lombok.Data;

@Data
public class JndiPropertyHolder {
	private String jndiName;
	private String driverClassName;
}
