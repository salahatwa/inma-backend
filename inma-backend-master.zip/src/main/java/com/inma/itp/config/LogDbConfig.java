package com.inma.itp.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "logEntityManagerFactory", transactionManagerRef = "logTransactionManager", basePackages = {
		"com.inma.itp.common.logging.repository" })
public class LogDbConfig extends DbConfig {

	@Bean
	@ConfigurationProperties(prefix = "spring.datasource.log")
	public JndiPropertyHolder log() {
		return new JndiPropertyHolder();
	}

	@Bean(name = "logDataSource")
	public DataSource dataSource() {
		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
		DataSource dataSource = dataSourceLookup.getDataSource(log().getJndiName());
		return dataSource;
	}

	@Bean(name = "logEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean logEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("logDataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("com.inma.itp.common.logging.model").persistenceUnit("log")
				.properties(jpaProperties()).build();
	}

	@Bean(name = "logTransactionManager")
	public PlatformTransactionManager logTransactionManager(
			@Qualifier("logEntityManagerFactory") EntityManagerFactory logEntityManagerFactory) {
		return new JpaTransactionManager(logEntityManagerFactory);
	}
}
