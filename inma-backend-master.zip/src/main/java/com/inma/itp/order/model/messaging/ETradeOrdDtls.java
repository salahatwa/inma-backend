package com.inma.itp.order.model.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.inma.itp.common.model.domain.CurAmt;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class ETradeOrdDtls {
	@XmlElement(name = "OrdSide")
	private String ordSide;

	@XmlElement(name = "Symbol")
	private String symbol;

	@XmlElement(name = "PortfolioNum")
	private String portfolioNum;

	@XmlElement(name = "OrdCommiss")
	private String ordCommiss;

	@XmlElement(name = "UsrId")
	private String usrId;

	@XmlElement(name = "ExcTotalAmt")
	private String excTotalAmt;

	@XmlElement(name = "TIFType")
	private String tifType;

	@XmlElement(name = "OrdTm")
	private String ordTm;

	@XmlElement(name = "OrdStatus")
	private String ordStatus;

	@XmlElement(name = "TaxInfo")
	private TaxInfo taxInfo = new TaxInfo();

	@XmlElement(name = "AvgPrice")
	private String avgPrice;

	@XmlElement(name = "MrktPrice")
	private String mrktPrice;

	@XmlElement(name = "MrktCode")
	private String mrktCode;

	@XmlElement(name = "ExcQty")
	private String excQty;

	@XmlElement(name = "TADCommiss")
	private String tadCommiss;

	@XmlElement(name = "CIF")
	private String cif;

	@XmlElement(name = "OMSRefNum")
	private String omsRefNum;

	@XmlElement(name = "Broker")
	private String broker;

	@XmlElement(name = "OrdDtHjr")
	private String ordDtHjr;

	@XmlElement(name = "OrdType")
	private String ordType;

	@XmlElement(name = "BrokerCommiss")
	private String brokerCommiss;

	@XmlElement(name = "ExpDt")
	private String expDt;

	@XmlElement(name = "SAMAAcctNum")
	private String samaAcctNum;

	@XmlElement(name = "MrktRefNum")
	private String mrktRefNum;

	@XmlElement(name = "BankCommiss")
	private String bankCommiss;

	@XmlElement(name = "SCId")
	private String scId;

	@XmlElement(name = "RmnngQty")
	private String rmnngQty;

	@XmlElement(name = "OrdQty")
	private String ordQty;

	@XmlElement(name = "MaxFloor")
	private String maxFloor;

	@XmlElement(name = "CurAmt")
	private CurAmt curAmt = new CurAmt();

	@XmlElement(name = "MrktAuthrzd")
	private String mrktAuthrzd;

	@XmlElement(name = "DealerId")
	private String dealerId;

	@XmlElement(name = "OrdDt")
	private String ordDt;
	
	@XmlElement(name = "SecShortNameEn")
	private String secShortNameEn;
	
	@XmlElement(name = "SecShortNameAr")
	private String secShortNameAr;
	
	@XmlElement(name = "OrdRejectReason")
	private String ordRejectReason;
	
	@XmlElement(name = "MinFillQty")
	private String minFillQty;
	
	@XmlElement(name = "StopPrice")
	private String stopPrice;
	
}