package com.inma.itp.order.api;

import java.util.List;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inma.itp.common.annotations.CurrentUser;
import com.inma.itp.common.security.UserPrincipal;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.order.model.dto.CommissionRequest;
import com.inma.itp.order.model.dto.ETradeOrdDtlsDto;
import com.inma.itp.order.model.dto.OrderInquiryRequest;
import com.inma.itp.order.model.dto.OrderInquiryResponse;
import com.inma.itp.order.model.dto.OrderRequest;
import com.inma.itp.order.model.dto.OrderResponse;
import com.inma.itp.order.service.OrderService;

/**
 * Api to for order managing
 * 
 * @author ssatwa
 *
 */
@RestController
@Validated
@RequestMapping("${api.context.path}/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	/**
	 * Get all commission details
	 * 
	 * @param currentUser
	 * @param commissionRequest
	 * @return Commission details
	 */
	@PostMapping("/commission/details")
	public ResponseEntity<?> getCommissionDetails(@CurrentUser UserPrincipal currentUser,
			@RequestBody CommissionRequest commReq) {

		return ResponseEntity.ok(orderService.getCommissionDetails(currentUser.getId(), commReq));
	}

	/**
	 * Execute Order
	 * 
	 * @param currentUser
	 * @param orderRequest
	 * @return reference for order
	 */
	@PostMapping("/execute")
	public ResponseEntity<ETradeOrdDtlsDto> executeOrder(@CurrentUser UserPrincipal currentUser,
			@RequestBody OrderRequest ordReq) {
		OrderResponse ordRes = orderService.executeOrder(currentUser.getId(), ordReq);

		return ResponseEntity.ok(orderService.getOrderStatus(currentUser.getId(), ordRes.getOrdRefNum()));
	}

	/**
	 * Update Order
	 * 
	 * @param currentUser
	 * @param orderRequest
	 * @return reference for order
	 */
	@PutMapping("/update")
	public ResponseEntity<ETradeOrdDtlsDto> updateOrder(@CurrentUser UserPrincipal currentUser,
			@RequestBody OrderRequest ordReq) {
		OrderResponse ordRes = orderService.updateOrder(currentUser.getId(), ordReq);
		return ResponseEntity.ok(orderService.getOrderStatus(currentUser.getId(), ordRes.getOrdRefNum()));
	}

	/**
	 * Get order Status
	 * 
	 * @param currentUser
	 * @param ordRefNum
	 * @return
	 */
	@GetMapping("/{ordRefNum}/status")
	public ResponseEntity<ETradeOrdDtlsDto> getOrderStatus(@CurrentUser UserPrincipal currentUser,
			@PathVariable("ordRefNum") String ordRefNum) {

		return ResponseEntity.ok(orderService.getOrderStatus(currentUser.getId(), ordRefNum));
	}

	/**
	 * Inquiry order
	 * 
	 * @param currentUser
	 * @param inqReq
	 * @return
	 */
	@PostMapping("/inquiry")
	public ResponseEntity<?> inquireOrders(@CurrentUser UserPrincipal currentUser,
			@RequestBody OrderInquiryRequest inqReq) {

		return ResponseEntity.ok(orderService.inquireOrders(currentUser.getId(), inqReq));
	}

	@GetMapping("/{ordRefNum}/{portfolioNumber}/details")
	public ResponseEntity<ETradeOrdDtlsDto> getOrderDetails(@CurrentUser UserPrincipal currentUser,
			@NotBlank(message = Constants.PORTFOLIO_NUMBER_REQUIRED_MSG) @PathVariable("portfolioNumber") String portfolioNumber,
			@NotBlank(message = Constants.OMS_REF_NUMBER_REQUIRED_MSG) @PathVariable("ordRefNum") String ordRefNum) {

		return ResponseEntity.ok(orderService.getOrderDetails(currentUser.getId(), portfolioNumber, ordRefNum));
	}

	@PostMapping("/outstandingOrders")
	public ResponseEntity<OrderInquiryResponse> getOutstandingOrders(@CurrentUser UserPrincipal currentUser,
			@RequestBody OrderInquiryRequest inqReq) {
		return ResponseEntity.ok(orderService.getOutstandingOrders(inqReq));
	}

	/**
	 * Canceling order , get latest status for given order
	 * 
	 * @param currentUser
	 * @param portfolioNumber
	 * @param ordRefNum
	 * @return
	 */
	@DeleteMapping("/{ordRefNum}/{portfolioNumber}")
	public ResponseEntity<ETradeOrdDtlsDto> cancelOrder(@CurrentUser UserPrincipal currentUser,
			@NotBlank(message = Constants.PORTFOLIO_NUMBER_REQUIRED_MSG) @PathVariable("portfolioNumber") String portfolioNumber,
			@NotBlank(message = Constants.OMS_REF_NUMBER_REQUIRED_MSG) @PathVariable("ordRefNum") String ordRefNum) {
		boolean isCanceled = orderService.cancelOrder(currentUser.getId(), portfolioNumber, ordRefNum);
		if (isCanceled)
			return ResponseEntity.ok(orderService.getOrderStatus(currentUser.getId(), ordRefNum));
		else
			return null;
	}

	@GetMapping("/{ordRefNum}/history")
	public ResponseEntity<List<ETradeOrdDtlsDto>> getOrderHistory(@CurrentUser UserPrincipal currentUser,
			@NotBlank(message = Constants.OMS_REF_NUMBER_REQUIRED_MSG) @PathVariable("ordRefNum") String ordRefNum) {

		return ResponseEntity.ok(orderService.getOrderHistory(currentUser.getId(), ordRefNum));
	}
}