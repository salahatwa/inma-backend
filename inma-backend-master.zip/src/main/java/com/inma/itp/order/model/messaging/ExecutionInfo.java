package com.inma.itp.order.model.messaging;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import lombok.Data;

@Data
@XmlAccessorType(XmlAccessType.FIELD)
public  class ExecutionInfo {

	@XmlElement(name = "TrnRefNum")
	private String executionRefNumber;
	
	@XmlElement(name = "ExcDt")
	private String executionDate;
	
	@XmlElement(name = "ExcQty")
	private String executedQuantity;
	
	@XmlElement(name = "ExcPrice")
	private String executedPrice;
	
	@XmlElement(name = "ExcAmt")
	private String executedAmount;
	
	@XmlElement(name = "BrokerCommiss")
	private String brokerCommission;
	
	@XmlElement(name = "BankCommiss")
	private String bankCommission;
	
	@XmlElement(name = "MrktCommiss")
	private String marketCommission;
	
	@XmlElement(name = "TotalAmt")
	private String totalAmt;
	
	@XmlElement(name = "SettlementDt")
	private String settlementDate;
	
	@XmlElement(name = "TaxInfo")
	private TaxInfo taxInfo =new TaxInfo();
}
