package com.inma.itp.order.model.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.inma.itp.common.model.domain.RecCtrlOut;
import com.inma.itp.common.model.messaging.QueueResMsg;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@XmlRootElement(name = "eTradeOrdsInqRs")
public class ETradeOrdsInqRs extends QueueResMsg {

	private static final long serialVersionUID = 2029868688818296210L;

	@XmlPath("Body/RecCtrlOut")
	private RecCtrlOut RecCtrlOut = new RecCtrlOut();

	@JacksonXmlElementWrapper(useWrapping = false)
	@XmlPath("Body/OrdsList/eTradeOrdDtls")
	private List<ETradeOrdDtls> eTradeOrdDtls = new ArrayList<>();
}
