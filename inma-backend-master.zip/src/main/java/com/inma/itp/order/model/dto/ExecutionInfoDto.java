package com.inma.itp.order.model.dto;


import lombok.Data;

@Data
public class ExecutionInfoDto {

	private String executionRefNumber;
	private String executionDate;
	private String executedQuantity;
	private String executedPrice;
	private String executedAmount;
	private String brokerCommission;
	private String bankCommission;
	private String marketCommission;
	private String totalAmt;
	private String settlementDate;
	private TaxInfoDto taxInfo;
}
