package com.inma.itp.order.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.messaging.MessageTemplateService;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.order.model.messaging.ETradeOrdDtlsInqRq;
import com.inma.itp.order.model.messaging.ETradeOrdDtlsInqRs;
import com.inma.itp.order.model.messaging.ETradeOrdMngRq;
import com.inma.itp.order.model.messaging.ETradeOrdMngRs;
import com.inma.itp.order.model.messaging.ETradeOrdsInqRq;
import com.inma.itp.order.model.messaging.ETradeOrdsInqRs;
import com.inma.itp.order.model.messaging.ETradePreOrdDtlsInqRq;
import com.inma.itp.order.model.messaging.ETradePreOrdDtlsInqRs;

@Service
public class OrderDao {

	@Autowired
	private MessageTemplateService msgTemplateService;

	/**
	 * Get all commission details
	 * 
	 * @param currentUser
	 * @param commissionRequest
	 * @return Commission details
	 */
	public Optional<ETradePreOrdDtlsInqRs> getCommissionDetails(String userId, ETradePreOrdDtlsInqRq rq) {
		rq.setFuncId(Constants.FUNCTION_PORTOLIO_COMMISSION);
		rq.setAgentId(userId);
		return msgTemplateService.sendMessage(rq, ETradePreOrdDtlsInqRs.class);
	}

	public Optional<ETradeOrdMngRs> executeOrder(String userId, ETradeOrdMngRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_MNG);
		rq.setAgentId(userId);
		return msgTemplateService.sendMessage(rq, ETradeOrdMngRs.class);
	}

	public Optional<ETradeOrdMngRs> updateOrder(String userId, ETradeOrdMngRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_UPDATE);
		rq.setAgentId(userId);
		return msgTemplateService.sendMessage(rq, ETradeOrdMngRs.class);
	}
	public Optional<ETradeOrdMngRs> cancelOrder(ETradeOrdMngRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_CANCEL);
		return msgTemplateService.sendMessage(rq, ETradeOrdMngRs.class);
	}
	

	public Optional<ETradeOrdsInqRs> getOrderStatus(String userId, ETradeOrdsInqRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_INQ);
		rq.setAgentId(userId);
		return msgTemplateService.sendMessage(rq, ETradeOrdsInqRs.class);
	}

	public Optional<ETradeOrdsInqRs> inquiryOrders(String userId, ETradeOrdsInqRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_INQ);
		rq.setAgentId(userId);
		return msgTemplateService.sendMessage(rq, ETradeOrdsInqRs.class);
	}

	public Optional<ETradeOrdDtlsInqRs> getOrderDetails(ETradeOrdDtlsInqRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_DETAILS);
		return msgTemplateService.sendMessage(rq, ETradeOrdDtlsInqRs.class);
	}

	public Optional<ETradeOrdsInqRs> getOutstandingOrders(ETradeOrdsInqRq rq) {
		rq.setFuncId(Constants.FUNCTION_OUSTANDING_ORDERS);
		return msgTemplateService.sendMessage(rq, ETradeOrdsInqRs.class);
	}
	
	public Optional<ETradeOrdsInqRs> getOrderHistory(ETradeOrdsInqRq rq) {
		rq.setFuncId(Constants.FUNCTION_ORD_HISTORY);
		return msgTemplateService.sendMessage(rq, ETradeOrdsInqRs.class);
	}

}
