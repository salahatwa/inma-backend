package com.inma.itp.order.model.messaging;

import javax.xml.bind.annotation.XmlElement;

import lombok.Data;

@Data
public  class TaxInfo {
	@XmlElement(name = "TaxPercen")
	private String taxPercen;

	@XmlElement(name = "TaxType")
	private String taxType;

	@XmlElement(name = "TaxAmt")
	private String taxAmt;
	
	@XmlElement(name = "InvoiceNum")
	private String invoiceNum;
}
