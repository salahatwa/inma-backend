package com.inma.itp.order.model.dto;

import lombok.Data;

@Data
public class TaxInfoDto {
	private String taxPercen;

	private String taxType;

	private String taxAmt;
	
	private String invoiceNum;
}
