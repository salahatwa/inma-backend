package com.inma.itp.order.model.dto;

import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class OrderRequest {

	private String omsRefNum;

	@NotBlank
	private String stockSymbol;

	@NotBlank
	private String portfolioNum;

	/**
	 * SPR for BUY SSL for sell
	 */
	@NotBlank
	private String orderSide;

	private int orderQty;

	/**
	 * 
	 */
	private int orderType;

	private int tifType;

	private String expDt;

	private double unitPrice;

	private double minFillQty;

}
