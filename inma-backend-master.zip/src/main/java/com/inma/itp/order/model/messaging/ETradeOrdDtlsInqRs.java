package com.inma.itp.order.model.messaging;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.inma.itp.common.model.domain.RecCtrlOut;
import com.inma.itp.common.model.messaging.QueueResMsg;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@XmlRootElement(name = "eTradeOrdDtlsInqRs")
public class ETradeOrdDtlsInqRs extends QueueResMsg {

	private static final long serialVersionUID = -8365432872966869605L;

	@XmlPath("Body/RecCtrlOut")
	private RecCtrlOut RecCtrlOut = new RecCtrlOut();

	@XmlPath("Body/eTradeOrdDtls")
	private ETradeOrdDtls eTradeOrdDtls = new ETradeOrdDtls() ;
	@XmlPath("Body/ExcsList/ExcInfo")
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<ExecutionInfo> executionInfoList = new ArrayList<ExecutionInfo>();
}
