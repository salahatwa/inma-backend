package com.inma.itp.order.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageValidationHelper;
import com.inma.itp.common.model.domain.DtRange;
import com.inma.itp.common.model.dto.CurAmtDto;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.order.dao.OrderDao;
import com.inma.itp.order.model.dto.CommissionRequest;
import com.inma.itp.order.model.dto.CommissionResponse;
import com.inma.itp.order.model.dto.ETradeOrdDtlsDto;
import com.inma.itp.order.model.dto.ExecutionInfoDto;
import com.inma.itp.order.model.dto.OrderInquiryRequest;
import com.inma.itp.order.model.dto.OrderInquiryResponse;
import com.inma.itp.order.model.dto.OrderRequest;
import com.inma.itp.order.model.dto.OrderResponse;
import com.inma.itp.order.model.dto.TaxInfoDto;
import com.inma.itp.order.model.messaging.ETradeOrdDtls;
import com.inma.itp.order.model.messaging.ETradeOrdDtlsInqRq;
import com.inma.itp.order.model.messaging.ETradeOrdDtlsInqRs;
import com.inma.itp.order.model.messaging.ETradeOrdMngRq;
import com.inma.itp.order.model.messaging.ETradeOrdMngRs;
import com.inma.itp.order.model.messaging.ETradeOrdsInqRq;
import com.inma.itp.order.model.messaging.ETradeOrdsInqRs;
import com.inma.itp.order.model.messaging.ETradePreOrdDtlsInqRq;
import com.inma.itp.order.model.messaging.ETradePreOrdDtlsInqRs;
import com.inma.itp.order.model.messaging.ExecutionInfo;

@Service
public class OrderService {

	@Autowired
	private OrderDao orderDao;

	/**
	 * Get all commission details
	 * 
	 * @param currentUser
	 * @param commissionRequest
	 * @return Commission details
	 */
	public CommissionResponse getCommissionDetails(String userId, CommissionRequest commReq) {

		ETradePreOrdDtlsInqRq request = new ETradePreOrdDtlsInqRq();
		request.setPortfolioNum(commReq.getPortfolioNum());
		request.setSymbol(commReq.getStockSymbol());
		request.setOrdSide(commReq.getOrderSide());
		request.setOrdType(String.valueOf(commReq.getOrderType()));
		request.setOrdQty(String.valueOf(commReq.getOrderQty()));
		request.setUnitPrice(String.valueOf(commReq.getUnitPrice()));

		ETradePreOrdDtlsInqRs eTradePreOrdDtlsInqRs = orderDao.getCommissionDetails(userId, request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));
		if (MessageValidationHelper.isValidResponse(eTradePreOrdDtlsInqRs)) {
			CommissionResponse res = new CommissionResponse();
			BeanUtils.copyProperties(eTradePreOrdDtlsInqRs, res);
			return res;
		} else {
			throw new MqException(eTradePreOrdDtlsInqRs.getStatusCode());
		}
	}

	public OrderResponse executeOrder(String userId, OrderRequest ordReq) {
		ETradeOrdMngRq request = new ETradeOrdMngRq();
		request.setProduct(Constants.PRODUCT);
		request.setMinFillQty(ordReq.getMinFillQty() + "");
		request.setTifType(ordReq.getTifType() + "");
		request.setExpDt(ordReq.getExpDt());
		request.setPortfolioNum(ordReq.getPortfolioNum());
		request.setSymbol(ordReq.getStockSymbol());
		request.setOrdSide(ordReq.getOrderSide());
		request.setOrdType(String.valueOf(ordReq.getOrderType()));
		request.setOrdQty(String.valueOf(ordReq.getOrderQty()));
		request.getCurAmt().setAmt(String.valueOf(ordReq.getUnitPrice()));

		ETradeOrdMngRs rs = orderDao.executeOrder(userId, request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));
		if (MessageValidationHelper.isValidResponse(rs)) {
			return new OrderResponse(rs.getSpRefNum());
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	public OrderResponse updateOrder(String userId, OrderRequest ordReq) {
		ETradeOrdMngRq request = new ETradeOrdMngRq();
		request.setOmsRefNum(ordReq.getOmsRefNum());
		request.setProduct(Constants.PRODUCT);
		request.setMinFillQty(ordReq.getMinFillQty() + "");
		request.setTifType(ordReq.getTifType() + "");
		request.setExpDt(ordReq.getExpDt());
		request.setPortfolioNum(ordReq.getPortfolioNum());
		request.setSymbol(ordReq.getStockSymbol());
		request.setOrdSide(ordReq.getOrderSide());
		request.setOrdType(String.valueOf(ordReq.getOrderType()));
		request.setOrdQty(String.valueOf(ordReq.getOrderQty()));
		request.getCurAmt().setAmt(String.valueOf(ordReq.getUnitPrice()));

		ETradeOrdMngRs rs = orderDao.updateOrder(userId, request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));
		if (MessageValidationHelper.isValidResponse(rs)) {
			return new OrderResponse(rs.getSpRefNum());
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	public boolean cancelOrder(String userId, String portfolioNum, String omsRefNum) {
		ETradeOrdMngRq request = new ETradeOrdMngRq();
		request.setOmsRefNum(omsRefNum);
		request.setProduct(Constants.PRODUCT);
		request.setAgentId(userId);
		request.setPortfolioNum(portfolioNum);
		ETradeOrdMngRs rs = orderDao.cancelOrder(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));
		if (MessageValidationHelper.isValidResponse(rs)) {
			return true;
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	public ETradeOrdDtlsDto getOrderStatus(String userId, String ordRefNum) {
		ETradeOrdsInqRq request = new ETradeOrdsInqRq();
		request.setProduct(Constants.PRODUCT);
		request.setOwnOrder("Y");
		DtRange date = new DtRange();
		date.setEndDt(Constants.DATE_DEFAULT);
		date.setStartDt(Constants.DATE_DEFAULT);
		request.setDtRange(date);
		request.setOmsRefNum(ordRefNum);

		ETradeOrdsInqRs rs = orderDao.getOrderStatus(userId, request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));
		if (MessageValidationHelper.isValidResponse(rs)) {
			return convertETradeOrdDtlsToETradeOrdDtlsDto(rs.getETradeOrdDtls().get(0), null);
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	public OrderInquiryResponse inquireOrders(String userId, OrderInquiryRequest inqReq) {
		ETradeOrdsInqRq request = new ETradeOrdsInqRq();
		request.setPortfolioNum(inqReq.getPortfolioNum());
		request.setOrdStatus(inqReq.getOrdStatus());
		request.setProduct(Constants.PRODUCT);
		request.setOrdSide(inqReq.getOrderSide());
		request.setSymbol(inqReq.getStockSymbol());
		request.setDtRange(inqReq.getDtRange());
		if (inqReq.getOrdRefNum() != null && !inqReq.getOrdRefNum().equals("")) {
			request.setOmsRefNum(inqReq.getOrdRefNum());
		}
		if (inqReq.getRecCtrlIn() != null) {
			request.getRecCtrlIn().setOffset(inqReq.getRecCtrlIn().getOffset());
			request.getRecCtrlIn().setMaxRecs(inqReq.getRecCtrlIn().getMaxRecs());
		}
		if (inqReq.isMyOrders()) {
			request.setOwnOrder("Y");
		}

		ETradeOrdsInqRs rs = orderDao.inquiryOrders(userId, request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			OrderInquiryResponse response = new OrderInquiryResponse();
			List<ETradeOrdDtls> ordersList = Optional.ofNullable(rs.getETradeOrdDtls()).filter(o -> o.size() > 0)
					.map(o -> rs.getETradeOrdDtls().stream()
							.filter(order -> order.getOmsRefNum() != null && !order.getOmsRefNum().equals(""))
							.map(ordrDtls -> ordrDtls).collect(Collectors.toList()))
					.orElse(new ArrayList<>());

			if (ordersList != null) {
				response.setOrdersList(ordersList);
				response.setRecCtrlOut(rs.getRecCtrlOut());
			} else {
				throw new ResourceNotFoundException(Constants.ORDER_NOTFOUND_MSG);
			}

			return response;
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	public ETradeOrdDtlsDto getOrderDetails(String userId, String portfolioNumber, String omsRefNum) {

		ETradeOrdDtlsInqRq request = new ETradeOrdDtlsInqRq();
		request.setPortfolioNum(portfolioNumber);
		request.setProduct(Constants.PRODUCT);
		request.setAgentId(userId);
		request.setOmsRefNum(omsRefNum);
		ETradeOrdDtlsInqRs rs = orderDao.getOrderDetails(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			if (rs.getETradeOrdDtls().getOrdStatus() == null || rs.getETradeOrdDtls().getOrdStatus().isEmpty()) {
				throw new ResourceNotFoundException(Constants.ORDER_NOTFOUND_MSG);
			} else {
				return convertETradeOrdDtlsToETradeOrdDtlsDto(rs.getETradeOrdDtls(), rs.getExecutionInfoList());
			}

		} else
			throw new MqException(rs.getStatusCode());
	}

	public OrderInquiryResponse getOutstandingOrders(OrderInquiryRequest inqReq) {
		ETradeOrdsInqRq request = new ETradeOrdsInqRq();
		request.setPortfolioNum(inqReq.getPortfolioNum());
		request.setOrdStatus(inqReq.getOrdStatus());
		request.setProduct(Constants.PRODUCT);
		request.setOrdSide(inqReq.getOrderSide());
		request.setSymbol(inqReq.getStockSymbol());
		request.setDtRange(inqReq.getDtRange());
		if (inqReq.getOrdRefNum() != null && !inqReq.getOrdRefNum().equals("")) {
			request.setOmsRefNum(inqReq.getOrdRefNum());
		}
		if (inqReq.getRecCtrlIn() != null) {
			request.getRecCtrlIn().setOffset(inqReq.getRecCtrlIn().getOffset());
			request.getRecCtrlIn().setMaxRecs(inqReq.getRecCtrlIn().getMaxRecs());
		}

		ETradeOrdsInqRs rs = orderDao.getOutstandingOrders(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			OrderInquiryResponse response = new OrderInquiryResponse();
			List<ETradeOrdDtls> ordersList = Optional.ofNullable(rs.getETradeOrdDtls()).filter(o -> o.size() > 0)
					.map(o -> rs.getETradeOrdDtls().stream()
							.filter(order -> order.getOmsRefNum() != null && !order.getOmsRefNum().equals(""))
							.map(ordrDtls -> ordrDtls).collect(Collectors.toList()))
					.orElse(new ArrayList<>());

			if (ordersList != null) {
				response.setOrdersList(ordersList);
				response.setRecCtrlOut(rs.getRecCtrlOut());
			} else {
				throw new ResourceNotFoundException(Constants.ORDER_NOTFOUND_MSG);
			}
			return response;
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	private ETradeOrdDtlsDto convertETradeOrdDtlsToETradeOrdDtlsDto(ETradeOrdDtls model,
			List<ExecutionInfo> executionInfoList) {

		ETradeOrdDtlsDto dto = new ETradeOrdDtlsDto();
		BeanUtils.copyProperties(model, dto);

		dto.setCurAmt(Optional.ofNullable(model.getCurAmt()).map(curAmt -> {
			CurAmtDto curAmtDto = new CurAmtDto();
			BeanUtils.copyProperties(curAmt, curAmtDto);
			return curAmtDto;
		}).orElse(null));

		dto.setTaxInfo(Optional.ofNullable(model.getTaxInfo()).map(tax -> {
			TaxInfoDto taxDto = new TaxInfoDto();
			BeanUtils.copyProperties(tax, taxDto);
			return taxDto;
		}).orElse(null));

		if (executionInfoList != null && !executionInfoList.isEmpty()) {
			dto.setExecutionInfoList(new ArrayList<ExecutionInfoDto>());
			dto.setExecutionInfoList(executionInfoList.stream().map(executionInfo -> {
				ExecutionInfoDto execInfoDto = new ExecutionInfoDto();
				BeanUtils.copyProperties(executionInfo, execInfoDto);
				return execInfoDto;
			}).collect(Collectors.toList()));
		}

		return dto;
	}

	public List<ETradeOrdDtlsDto> getOrderHistory(String userId, String omsRefNumber) {
		ETradeOrdsInqRq request = new ETradeOrdsInqRq();
		request.setProduct(Constants.PRODUCT);
		request.setOmsRefNum(omsRefNumber);
		request.getRecCtrlIn().setOffset(Constants.OFFSET);
		request.getRecCtrlIn().setMaxRecs(Constants.MAX_RECORDS);
		request.setAgentId(userId);

		ETradeOrdsInqRs rs = orderDao.getOrderHistory(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			List<ETradeOrdDtlsDto> orderHistoryList = Optional.ofNullable(rs.getETradeOrdDtls())
					.filter(o -> o.size() > 0)
					.map(o -> rs.getETradeOrdDtls().stream()
							.filter(order -> order.getOmsRefNum() != null && !order.getOmsRefNum().equals(""))
							.map(ordrDtls -> convertETradeOrdDtlsToETradeOrdDtlsDto(ordrDtls, null))
							.collect(Collectors.toList()))
					.orElse(new ArrayList<>());

			if (orderHistoryList != null && orderHistoryList.size() > 0) {
				Collections.reverse(orderHistoryList);
				return orderHistoryList;
			} else {
				throw new ResourceNotFoundException(Constants.ORDER_NOTFOUND_MSG);
			}

		} else {
			throw new MqException(rs.getStatusCode());
		}
	}
}
