package com.inma.itp.order.model.dto;

import java.util.List;

import com.inma.itp.common.model.domain.RecCtrlOut;
import com.inma.itp.order.model.messaging.ETradeOrdDtls;

import lombok.Data;

@Data
public class OrderInquiryResponse {
	private List<ETradeOrdDtls> ordersList;
	private RecCtrlOut recCtrlOut;
}
