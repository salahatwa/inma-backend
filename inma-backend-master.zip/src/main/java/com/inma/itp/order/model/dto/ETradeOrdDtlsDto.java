package com.inma.itp.order.model.dto;

import java.util.List;

import com.inma.itp.common.model.dto.CurAmtDto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class ETradeOrdDtlsDto {
	private String ordSide;

	private String symbol;

	private String portfolioNum;

	private String ordCommiss;

	private String usrId;

	private String excTotalAmt;

	private String tifType;

	private String ordTm;

	private String ordStatus;

	private TaxInfoDto taxInfo = new TaxInfoDto();

	private String avgPrice;

	private String mrktPrice;

	private String mrktCode;

	private String excQty;

	private String tadCommiss;

	private String cif;

	private String omsRefNum;

	private String broker;

	private String ordDtHjr;

	private String ordType;

	private String brokerCommiss;

	private String expDt;

	private String samaAcctNum;

	private String mrktRefNum;

	private String bankCommiss;

	private String scId;

	private String rmnngQty;

	private String ordQty;

	private String maxFloor;

	private CurAmtDto curAmt;

	private String mrktAuthrzd;

	private String dealerId;

	private String ordDt;

	private String secShortNameEn;

	private String secShortNameAr;
	
	private String ordRejectReason;
	
	private String minFillQty;
	
	private String stopPrice;
	
	private List<ExecutionInfoDto> executionInfoList ;




}
