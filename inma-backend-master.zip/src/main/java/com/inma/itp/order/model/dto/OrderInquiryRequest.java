package com.inma.itp.order.model.dto;

import com.inma.itp.common.model.domain.DtRange;
import com.inma.itp.common.model.domain.RecCtrlIn;

import lombok.Data;

@Data
public class OrderInquiryRequest {
	private String ordRefNum;
	private String stockSymbol;
	private String portfolioNum;
	/**
	 * SPR for BUY SSL for sell
	 */
	private String orderSide;
	private String ordStatus;
	private DtRange dtRange;
	private RecCtrlIn recCtrlIn;
	private boolean myOrders;
}
