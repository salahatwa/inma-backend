package com.inma.itp.order.model.messaging;

import javax.xml.bind.annotation.XmlRootElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.inma.itp.common.annotations.InmaQueue;
import com.inma.itp.common.model.messaging.QueueReqMsg;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@XmlRootElement(name = "eTradeOrdDtlsInqRq")
@InmaQueue(requestQueue = "eTradeOrdDtlsInqRq", responseQueue = "eTradeOrdDtlsInqRs")
public class ETradeOrdDtlsInqRq extends QueueReqMsg {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5227644137347816739L;

	public ETradeOrdDtlsInqRq(String funcId, String agentId) {
		super(funcId);
		this.setAgentId(agentId);
	}

	@XmlPath("Body/Product/text()")
	private String product;

	@XmlPath("Body/PortfolioNum/text()")
	private String portfolioNum;

	@XmlPath("Body/OMSRefNum/text()")
	private String omsRefNum;

	

}
