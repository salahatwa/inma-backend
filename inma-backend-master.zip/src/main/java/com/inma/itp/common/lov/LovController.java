package com.inma.itp.common.lov;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inma.itp.common.annotations.CurrentUser;
import com.inma.itp.common.security.UserPrincipal;

/**
 * Api to return Customers details
 * 
 * @author ssatwa
 *
 */
@RestController
@RequestMapping("${api.context.path}/lov")
@Validated
public class LovController {

	@Autowired
	private LovService lovService;

	/**
	 * list of values Inquiry
	 */
	@PostMapping("/inquiry")
	public ResponseEntity<LOVInqRs> inquiryLov(@CurrentUser UserPrincipal currentUser,
			@Valid @RequestBody LovRequestDto param) {

		return ResponseEntity.ok(lovService.inquiryLov(param).get());
	}

}
