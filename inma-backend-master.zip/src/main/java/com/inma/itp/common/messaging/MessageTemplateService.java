package com.inma.itp.common.messaging;

import java.util.Optional;

import com.inma.itp.common.model.messaging.QueueReqMsg;
import com.inma.itp.common.model.messaging.QueueResMsg;

public interface MessageTemplateService {

	/**
	 * @param <R>    Request Object
	 * @param <T>    Response Object
	 * @param object
	 * @return
	 */
	public <R extends QueueReqMsg, T extends QueueResMsg> Optional<T> sendMessage(R requestObject, Class<T> responseType);
}
