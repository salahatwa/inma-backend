package com.inma.itp.common.lov;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.inma.itp.common.model.messaging.QueueResMsg;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@XmlRootElement(name = "LOVInqRs")
public class LOVInqRs extends QueueResMsg implements Serializable{

	@XmlPath("Body/SentRecs/text()")
	private String sentRecs;

	@XmlPath("Body/LOVList/LOVInfo")
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<LOVInfo> lovInfo;

	@Data
	@NoArgsConstructor
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class LOVInfo {
		@XmlElement(name = "RecTypeCode")
		private String recTypeCode;

		@XmlElement(name = "Attribute8")
		private String attribute8;

		@XmlElement(name = "Attribute6")
		private String attribute6;

		@XmlElement(name = "Attribute5")
		private String attribute5;

		@XmlElement(name = "Attribute4")
		private String attribute4;

		@XmlElement(name = "Attribute3")
		private String attribute3;

		@XmlElement(name = "Attribute2")
		private String attribute2;

		@XmlElement(name = "RecDesc")
		private String recDesc;

		@XmlElement(name = "Attribute1")
		private String attribute1;
	}

}
