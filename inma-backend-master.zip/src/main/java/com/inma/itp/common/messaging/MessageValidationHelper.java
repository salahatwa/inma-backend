package com.inma.itp.common.messaging;

import com.inma.itp.common.model.messaging.QueueResMsg;
import com.inma.itp.common.utils.Constants;

/**
 * Message validation
 * @author ssatwa
 *
 */
public class MessageValidationHelper {
	public static <T extends QueueResMsg> boolean isValidResponse(T responseObject) {
		return responseObject == null ?  false :  Constants.STATUS_CODE_SUCCESS.equals(responseObject.getStatusCode());
	}
	
	public static <T extends QueueResMsg> String  getStatusCode(T responseObject) {
		return responseObject == null ?  Constants.STATUS_CODE_INVALID_RESPONSE :  responseObject.getStatusCode();
	}
}
