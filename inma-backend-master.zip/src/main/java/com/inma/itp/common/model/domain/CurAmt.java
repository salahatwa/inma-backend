package com.inma.itp.common.model.domain;

import javax.xml.bind.annotation.XmlElement;

import lombok.Data;

@Data
public class CurAmt {
	@XmlElement(name = "CurCode")
	private String curCode;

	@XmlElement(name = "Amt")
	private String amt;
	
	@XmlElement(name = "AmtLcl")
	private String amtLcl;
	
	@XmlElement(name = "CurRate")
	private String curRate;
}