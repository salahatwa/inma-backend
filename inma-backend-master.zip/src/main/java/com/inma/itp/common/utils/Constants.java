package com.inma.itp.common.utils;

public interface Constants {
	public final static String PRODUCT = "LE";
	public final static String DATE_DEFAULT = "0001-01-01";
	public static final String ENVIRONMENT_INVESTMENT = "Investment";
	public static final String MAX_RECORDS = "50";
	public static final String OFFSET = "0";

	/**
	 * ALL Functions id
	 */
	public final static String FUNCTION_LOV_INQUIRY = "30020000";
	public final static String FUNCTION_ORD_MNG = "33000000";
	public final static String FUNCTION_ORD_UPDATE = "33001000";
	public final static String FUNCTION_ORD_INQ = "32000010";
	public final static String FUNCTION_ORD_DETAILS = "32001000";
	public final static String FUNCTION_OUSTANDING_ORDERS = "32000000";
	public final static String FUNCTION_ORD_CANCEL = "33002000";
	public final static String FUNCTION_ORD_HISTORY = "32000020";

	public final static String FUNCTION_AUTHENT = "10080000";
	public final static String AUTHENT_ATTR_TYPE = "4";
	public final static String AUTHENT_INFO_TYPE = "1";

	public final static String FUNCTION_PORTFOLIO_INQ = "32021000";
	public final static String FUNCTION_PORTFOLIO_POI_INQ = "32020000";
	public final static String FUNCTION_PORTOLIO_COMMISSION = "32130000";
	public final static String PORTFOLIO_TYPE = "IP";

	public final static String FUNCTION_CUSTOMER_INQ = "24000000";
	public final static String FUNCTION_SEC = "32110000";
	public final static String PRODUCT_CODE = "LSH";

	/**
	 * Status Codes
	 */
	public final static String STATUS_CODE_SUCCESS = "I000000";
	// E000000 : temp value till set the right value
	public final static String STATUS_CODE_INVALID_RESPONSE = "E000000";
	public final static String STATUS_CODE_TIMEOUT_RESPONSE = "E010222";
	public final static String STATUS_CODE_INVALID_LOV = "E000001";

	/*
	 * message keys
	 */
	public final static String PORTFOLIO_NUMBER_REQUIRED_MSG = "portfolioService.portfolioNumber.required";
	public final static String STOCK_SYMBOL_REQUIRED_MSG = "portfolioService.stockSymbol.required";
	public final static String STOCK_SYMBOL_DIGITS_ONLY_MSG = "portfolioService.stockSymbol.digitsOnly";
	public final static String POI_REQUIRED_MSG = "portfolioService.poiNumber.required";
	public final static String POI_DIGITS_ONLY_MSG = "portfolioService.poiNumber.digitsOnly";
	public final static String POI_LENGTH_MSG = "portfolioService.poiNumber.length";
	public final static String PORTFOLIO_NOTFOUND_MSG = "portfolioService.portfolioDetails.notFound";
	public final static String POI_HAS_NOT_PORTFOLIOS = "portfolioService.poi.portfolios.notFound";
	public final static String INVALID_DATA = "data.invalid";
	public final static String UN_EXPECTED_ERROR = "error.unexpected";
	public final static String ORDER_NOTFOUND_MSG = "orderService.orderDetails.notFound";
	public final static String OMS_REF_NUMBER_REQUIRED_MSG = "orderService.omsRefNumber.required";

	/**
	 * general message keys
	 */
	public final static String PARAM_REQUIRED = "param.required";
	
	/**
	 * LOCAL
	 */
	public final static String LOCAL_AR = "ar";
	public final static String LOCAL_EN = "en";

	/**
	 * LOV
	 */
	public final static String LOV_ADDRESS_TYPE = "ADDRESS_TYPE";
	public final static String LOV_PHONE_TYPE = "PHONE_TYPE";
	

}
