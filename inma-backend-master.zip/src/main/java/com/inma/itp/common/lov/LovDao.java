package com.inma.itp.common.lov;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.messaging.MessageTemplateService;
import com.inma.itp.common.utils.Constants;

@Service
public class LovDao {

	@Autowired
	private MessageTemplateService msgTemplateService;

	/**
	 * list of values Inquiry
	 */
	public Optional<LOVInqRs> inquiryLov(LOVInqRq rq) {

		rq.setFuncId(Constants.FUNCTION_LOV_INQUIRY);
		Optional<LOVInqRs> rs = msgTemplateService.sendMessage(rq, LOVInqRs.class);

		return rs;
	}

}
