package com.inma.itp.common.logging;

import java.net.UnknownHostException;
import java.util.Optional;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.inma.itp.common.logging.service.LoggingService;
import com.inma.itp.common.model.messaging.QueueReqMsg;
import com.inma.itp.common.model.messaging.QueueResMsg;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class LogAdapter {
	
	@Autowired
	LoggingService loggingService;
	
	@Around("@annotation(com.inma.itp.common.logging.annotations.LogExecutionTime)")
	public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
		long start = System.currentTimeMillis();
		Object proceed = joinPoint.proceed();
		long executionTime = System.currentTimeMillis() - start;
		log.info(joinPoint.getSignature() + " executed in " + executionTime + " ms");
		return proceed;
	}

	@Around("@annotation(com.inma.itp.common.logging.annotations.LogToDB)")
	public Object logToDB(ProceedingJoinPoint joinPoint) throws Throwable {
		long start = System.currentTimeMillis();
		QueueReqMsg queueReqMsg = (QueueReqMsg) joinPoint.getArgs()[0];
		Object resObject = joinPoint.proceed();
		QueueResMsg queueResMsg =(QueueResMsg) (((Optional<?>)resObject).get());
		long end = System.currentTimeMillis();
		long executionTime = end - start;
		
		try {
			loggingService.log(queueReqMsg, queueResMsg, start, end, executionTime);
		} catch (UnknownHostException e) {
			log.error("Unable to log request " + queueReqMsg.getRqUID());
		}
		return resObject;
	}
}
