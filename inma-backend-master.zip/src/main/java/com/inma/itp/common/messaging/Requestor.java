package com.inma.itp.common.messaging;

import java.util.Objects;

import javax.jms.Message;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.utils.Constants;

import lombok.extern.slf4j.Slf4j;

/**
 * Class responsible to send and receive message from MQ,
 * Queue Timeout handled
 * 
 * @author ssatwa
 *
 */
@Slf4j
@Component
public class Requestor {

	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${inma.queue.channel.prefix}")
	private String channelPrefix;

	@Value("${ibm.mq.timeout}")
	private int timeout;

	/**
	 * Send Message with unique ID to MQ and receive message filtered with this
	 * unique ID
	 * 
	 * @param msg
	 * @param queues
	 * @return
	 */
	public String request(final String msg, String[] queues) {
		try {

			MessageCreatorImpl messageCreator = new MessageCreatorImpl(jmsTemplate.getDestinationResolver(), queues,
					msg, channelPrefix);
			// Formulate the MQ request message and send it.
			jmsTemplate.setReceiveTimeout(timeout);
			jmsTemplate.send(channelPrefix + queues[0], messageCreator);

			Message backendReqMessage = messageCreator.getMessage();

			String selectedMsgId = "JMSCorrelationID='" + backendReqMessage.getJMSMessageID() + "'";

			Message respMsg = jmsTemplate.receiveSelected(channelPrefix + queues[1], selectedMsgId);

			TextMessage responseMessage = (TextMessage) respMsg;

			if (Objects.nonNull(responseMessage)) {
				log.info("Response: {}", responseMessage.getText());
				return responseMessage.getText();
			} else {
				log.info("Response: {}", "Null -> Timeout Issue");
				throw new MqException(Constants.STATUS_CODE_TIMEOUT_RESPONSE);
			}
		} catch (Exception ex) {
			throw new MqException(ex.getMessage());
		} finally {

		}
	}
}