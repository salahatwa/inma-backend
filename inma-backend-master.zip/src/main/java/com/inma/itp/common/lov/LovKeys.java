package com.inma.itp.common.lov;

public class LovKeys {
	public static final LovKey code1 = new LovKey("lovCode1");
	public static final LovKey code2 = new LovKey("lovCode2");
	public static final LovKey code3 = new LovKey("lovCode3");
	public static final LovKey code4 = new LovKey("lovCode4");
	public static final LovKey lang = new LovKey("lang");
	public static final LovKey echoData = new LovKey("echoData");
	public static final LovKey rqMode = new LovKey("rqMode");

}
