package com.inma.itp.common.logging.service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.inma.itp.auth.model.messaging.UsrAuthentRs;
import com.inma.itp.common.logging.model.domain.AlinmaLog;
import com.inma.itp.common.logging.repository.LoggingRepository;
import com.inma.itp.common.model.messaging.QueueReqMsg;
import com.inma.itp.common.model.messaging.QueueResMsg;
import com.inma.itp.common.utils.Constants;

@Service
public class LoggingService {
	@Autowired
	LoggingRepository loggingRepository;
	
	@Value("${applicationId}")
	private String applicationId;
	
	@Async
	public<T extends QueueReqMsg, R extends QueueResMsg> void log(T request, R response, long reqTime, long resTime, long execTime) throws UnknownHostException {
		AlinmaLog alinmaLog = new AlinmaLog();
		alinmaLog.setRequestId(request.getRqUID());
		if(Constants.FUNCTION_AUTHENT.equals(request.getFuncId())) {
			UsrAuthentRs rs = (UsrAuthentRs) response;
			alinmaLog.setMwUserId(rs.getUsrId());
		} else {			
			alinmaLog.setMwUserId(request.getAgentId());
		}
		alinmaLog.setChannelId(request.getScid());
		alinmaLog.setFunctionId(request.getFuncId());
		alinmaLog.setFileName("Integration");
		alinmaLog.setRqTime(new Timestamp(reqTime));
		alinmaLog.setRsTime(new Timestamp(resTime));
		alinmaLog.setWaitTime(execTime);
		alinmaLog.setStatusCode(response.getStatusCode());
		alinmaLog.setServer(InetAddress.getLocalHost().getHostName());
		alinmaLog.setApplication(applicationId);
		alinmaLog.setEnvironment(Constants.ENVIRONMENT_INVESTMENT);
		String serviceName = request.getClass().getSimpleName();
		alinmaLog.setServiceName(serviceName.substring(0, serviceName.length()-2));
		loggingRepository.save(alinmaLog);
	}
}
