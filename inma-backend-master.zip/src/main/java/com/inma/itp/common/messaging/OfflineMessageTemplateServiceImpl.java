package com.inma.itp.common.messaging;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.inma.itp.common.logging.annotations.LogToDB;
import com.inma.itp.common.model.messaging.QueueReqMsg;
import com.inma.itp.common.model.messaging.QueueResMsg;
import com.inma.itp.common.utils.ApplicationContextProvider;

import lombok.extern.slf4j.Slf4j;

/**
 * Generice Template Service implementation if isOffline equal true Load message
 * from offline-msg under resources folder
 * 
 * @author ssatwa
 *
 */
@Slf4j
@Service("offlineMessageTemplateServiceImpl")
public class OfflineMessageTemplateServiceImpl implements MessageTemplateService {

	@Autowired
	private QueueMessageTemplateServiceImpl queueMessageTemplateServiceImpl;

	@Autowired
	ResourceLoader resourceLoader;

	@Value("${fullOffline}")
	private boolean fullOffline;

	@Value("${offlineFunctionIds}")
	private String offlineFunctionIds;

	@LogToDB
	@Override
	public <R extends QueueReqMsg, T extends QueueResMsg> Optional<T> sendMessage(R requestObject,
			Class<T> responseType) {
		String rqMsg = MessageSerializerHelper.serializeToXML(requestObject);
		log.info("Sending message \n{}", rqMsg);
		String funcId = StringUtils.substringBetween(rqMsg, "<FuncId>", "</FuncId>");
		Optional<T> response = null;
		if (fullOffline || offlineFunctionIds.contains(funcId)) {
			response = Optional.ofNullable(MessageSerializerHelper
					.deserializeFromXML(getOfflineResponse(requestObject, funcId), responseType));
		} else {
			response = queueMessageTemplateServiceImpl.sendMessage(requestObject, responseType);
		}

		log.info("Received message \n{}", MessageSerializerHelper.serializeToXML(response));
		return response;
	}

	/**
	 * offline response should be under src/main/resources/offline-msg File name
	 * should be [ requestName-FunctionId.xml ]
	 * 
	 * @param object
	 * @return
	 */
	private String getOfflineResponse(Object object, String funcId) {
		try {
			String objectName = object.getClass().getSimpleName();
			String fileName = objectName.substring(0, objectName.length() - 2) + "Rs-" + funcId + ".xml";
			String offlineDirectory = ApplicationContextProvider.getEnvironmentProperty("offlineDirectory",
					String.class, "");
			Resource resource = resourceLoader.getResource("file:" + offlineDirectory + fileName);
			InputStream inputStream = resource.getInputStream();
			byte[] bdata = FileCopyUtils.copyToByteArray(inputStream);
			String xmlMsg = new String(bdata, StandardCharsets.UTF_8);
			return xmlMsg;
		} catch (Exception ex) {
			log.error("Error File not found {}" + ex.getMessage());
		}
		return null;
	}

}
