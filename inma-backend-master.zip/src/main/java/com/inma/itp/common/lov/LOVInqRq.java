package com.inma.itp.common.lov;

import javax.xml.bind.annotation.XmlRootElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.inma.itp.common.annotations.InmaQueue;
import com.inma.itp.common.model.messaging.QueueReqMsg;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@XmlRootElement(name = "LOVInqRq")
@InmaQueue(requestQueue = "LOVInqRq", responseQueue = "LOVInqRs")
public class LOVInqRq extends QueueReqMsg {

	@XmlPath("Body/LOVType/text()")
	private String lovType;

	@XmlPath("Body/LOVCode1/text()")
	private String lovCode1;

	@XmlPath("Body/LOVCode2/text()")
	private String lovCode2;

	@XmlPath("Body/LOVCode3/text()")
	private String lovCode3;

	@XmlPath("Body/LOVCode4/text()")
	private String lovCode4;

}
