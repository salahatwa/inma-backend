package com.inma.itp.common.lov;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class LovRequestDto {

	@NotBlank(message = "lov is mandatory")
	private String lov;

	private Map<LovKey, String> additionalParams = new HashMap<>();

	public LovRequestDto(String lov) {
		this.lov = lov;
	}

	public String get(LovKey fortKey) {
		return additionalParams.get(fortKey);
	}
}
