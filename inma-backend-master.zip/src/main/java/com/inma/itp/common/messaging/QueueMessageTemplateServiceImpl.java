package com.inma.itp.common.messaging;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.annotations.InmaQueue;
import com.inma.itp.common.logging.annotations.LogToDB;
import com.inma.itp.common.model.messaging.QueueReqMsg;
import com.inma.itp.common.model.messaging.QueueResMsg;

import lombok.extern.slf4j.Slf4j;

/**
 * Generice Template Service implementation if isOffline equal false Send
 * message to queue and get response from queue
 * 
 * @author ssatwa
 *
 */
@Slf4j
@Service("queueMessageTemplateServiceImpl")
public class QueueMessageTemplateServiceImpl implements MessageTemplateService {

	@Autowired
	private Requestor requestor;

	@LogToDB
	@Override
	public <R extends QueueReqMsg, T extends QueueResMsg> Optional<T> sendMessage(R requestObject, Class<T> responseType) {
		String rqMsg = MessageSerializerHelper.serializeToXML(requestObject);
		log.info("Sending message \n{}", rqMsg);
		
		// Implementation to send message to Queue and get response
		String response = requestor.request(rqMsg, getQueues(requestObject));
		log.info("Received message \n{}", response);

		T responseObject = (T) MessageSerializerHelper.deserializeFromXML(response, responseType);
		return Optional.ofNullable(responseObject);
	}

	/**
	 * Get Sender and response for Queues name if classes annotated with InmaQueue
	 * Else return sender queue in as class name And return response queue as class
	 * name +'Rs'
	 * 
	 * @param object
	 * @return
	 */
	private String[] getQueues(Object object) {
		String[] classQueues = new String[2];
		try {
			InmaQueue queues = object.getClass().getAnnotation(InmaQueue.class);
			classQueues[0] = queues.requestQueue();
			classQueues[1] = queues.responseQueue();

			return classQueues;
		} catch (Exception ex) {
			classQueues = new String[2];
			String className = object.getClass().getSimpleName();
			classQueues[0] = className;
			classQueues[1] = className.substring(0, className.length() - 2) + "Rs";
			return classQueues;
		}
	}
}
