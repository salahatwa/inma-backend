package com.inma.itp.common.model.dto;

import lombok.Data;

@Data
public class CurAmtDto {
	private String curCode;

	private String amt;
	
	private String amtLcl;
	
	private String curRate;
	
	
}