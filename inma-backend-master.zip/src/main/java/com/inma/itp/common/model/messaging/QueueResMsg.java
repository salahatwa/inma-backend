package com.inma.itp.common.model.messaging;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class QueueResMsg implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlPath("MsgRsHdr/RqUID/text()")
	private String rqUID;

	@XmlPath("MsgRsHdr/StatusCode/text()")
	private String statusCode;

	@XmlElement(name = "SPRefNum")
	@XmlPath("MsgRsHdr/SPRefNum/text()")
	private String spRefNum;

}
