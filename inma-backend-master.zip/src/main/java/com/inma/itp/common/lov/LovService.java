package com.inma.itp.common.lov;

import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageValidationHelper;
import com.inma.itp.common.utils.Constants;

@Component
public class LovService {

	@Autowired
	private LovDao lovDao;

	@Autowired
	private LovCustomProperties lovList;

	/**
	 * list of values Inquiry , Caching Expire after 1 hour
	 */
	@Cacheable(value = "lovCache", key = "#param.lov")
	public Optional<LOVInqRs> inquiryLov(LovRequestDto param) {

		LOVInqRq rq = new LOVInqRq();
		String lovType = lovList.getLovType(param.getLov());

		if (Objects.isNull(lovType))
			throw new ResourceNotFoundException(Constants.STATUS_CODE_INVALID_LOV);

		rq.setLovType(lovType);
		rq = initOptionalParam(param, rq);

		Optional<LOVInqRs> rs = lovDao.inquiryLov(rq);

		if (MessageValidationHelper.isValidResponse(rs.get())) {
			return rs;

		} else
			throw new MqException(rs.get().getStatusCode());

	}

	/**
	 * Initial optional parameters if found
	 * 
	 * @param param
	 * @param rq
	 * @return
	 */
	private LOVInqRq initOptionalParam(LovRequestDto param, LOVInqRq rq) {
		if (Objects.nonNull(param) && Objects.nonNull(param.getAdditionalParams())
				&& !param.getAdditionalParams().isEmpty()) {

			param.getAdditionalParams().forEach((key, value) -> {
				System.out.println("Key : " + key + " value : " + value);
				if (key.getKeyName() == LovKeys.code1.getKeyName())
					rq.setLovCode1(value);
				if (key.getKeyName() == LovKeys.code2.getKeyName())
					rq.setLovCode2(value);
				if (key.getKeyName() == LovKeys.code3.getKeyName())
					rq.setLovCode3(value);
				if (key.getKeyName() == LovKeys.code4.getKeyName())
					rq.setLovCode4(value);
				if (key.getKeyName() == LovKeys.lang.getKeyName())
					rq.setCustLangPref(value);
				if (key.getKeyName() == LovKeys.echoData.getKeyName())
					rq.setEchoData(value);
				if (key.getKeyName() == LovKeys.rqMode.getKeyName())
					rq.setRqMode(value);
			});

			return rq;
		}
		return rq;
	}

}
