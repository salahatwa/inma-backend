package com.inma.itp.common.lov;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:lov-data.properties")
@ConfigurationProperties("")
public class LovCustomProperties {
	private final Map<String, String> lovList = new HashMap<>();

	public Map<String, String> getLovList() {
		return lovList;
	}

	public String getLovType(String key) {
		return lovList.getOrDefault(key.toUpperCase(), null);
	}
}
