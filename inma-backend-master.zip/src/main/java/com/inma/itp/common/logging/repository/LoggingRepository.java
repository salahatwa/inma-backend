package com.inma.itp.common.logging.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.inma.itp.common.logging.model.domain.AlinmaLog;

@Repository
public interface LoggingRepository extends JpaRepository<AlinmaLog, String>{
	
}
