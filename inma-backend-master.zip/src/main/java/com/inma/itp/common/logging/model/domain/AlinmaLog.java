package com.inma.itp.common.logging.model.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "TDWL_LOGS")
public class AlinmaLog implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(sequenceName = "DB_LOGGING_SEQ", allocationSize = 1, name = "DB_LOGGING_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DB_LOGGING_SEQ")
	private Long id;
	
	@Column(name = "SERVER")
	private String server;
	
	@Column(name = "FILE_NAME")
	private String fileName;
	
	@Column(name = "CHANNEL_ID")
	private String channelId;
	
	@Column(name = "MQ_MGSID")
	private String mqMgsId;
	
	@Column(name = "REQUEST_TRACKING_ID")
	private String requestTrackingId;
	
	@Column(name = "REQUEST_ID")
	private String requestId;
	
	@Column(name = "STATUS_CODE")
	private String statusCode;
	
	@Column(name = "CIF")
	private String cif;
	
	@Column(name = "MW_USERID")
	private String mwUserId;
	
	@Column(name = "SERVICE_NAME")
	private String serviceName;
	
	@Column(name = "FUNCTION_ID")
	private String functionId;
	
	@Column(name = "AMOUNT")
	private double amount;
	
	@Column(name = "RQ_TIME")
	private Timestamp rqTime;
	
	@Column(name = "RS_TIME")
	private Timestamp rsTime;
	
	@Column(name = "WAIT_TIME")
	private long waitTime;
	
	@Column(name = "ORDER_TYPE")
	private String orderType;
	
	@Column(name = "SYMBOL")
	private String symbol;
	
	@Column(name = "QUANTITY")
	private String quantity;
	
	@Column(name = "TERMINAL_ID")
	private String terminalId;
	
	@Column(name = "APPLICATION")
	private String application;
	
	@Column(name = "SESSION_REF")
	private String sessionRef;
	
	@Column(name = "ID_NUMBER")
	private String idNumber;
	
	@Column(name = "CARD_NUMBER")
	private String cardNumber;
	
	@Column(name = "LOGIN_NAME")
	private String loginName;
	
	@Column(name = "ALINMA_ID")
	private String alinmaId;
	
	@Column(name = "ENVIRONMENT")
	private String environment;
}
