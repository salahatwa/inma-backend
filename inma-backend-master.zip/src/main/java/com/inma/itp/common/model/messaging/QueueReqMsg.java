package com.inma.itp.common.model.messaging;

import java.io.Serializable;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.inma.itp.common.utils.GenerateShortUUID;

import lombok.Data;

@Data
public class QueueReqMsg implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlPath("MsgRqHdr/RqUID/text()")
	private String rqUID;

	@XmlPath("MsgRqHdr/SCId/text()")
	private String scid;

	@XmlPath("MsgRqHdr/FuncId/text()")
	private String funcId;

	@XmlPath("MsgRqHdr/AgentId/text()")
	private String agentId;

	@XmlPath("MsgRqHdr/CustId/POI/POINum/text()")
	private String poiNum;

	@XmlPath("MsgRqHdr/CustId/POI/POIType/text()")
	private String poiType;

	@XmlPath("MsgRqHdr/CustId/CIF/text()")
	private String cif;

	@XmlPath("MsgRqHdr/CustLangPref/text()")
	private String custLangPref;

	@XmlPath("MsgRqHdr/RqMode/text()")
	private String rqMode;

	@XmlPath("MsgRqHdr/EchoData/text()")
	private String echoData;

	public QueueReqMsg() {
		this.rqUID = GenerateShortUUID.id();
		this.scid = GenerateShortUUID.getChannel();
	}

	public QueueReqMsg(String fucId) {
		super();
		this.funcId = fucId;
	}
}
