package com.inma.itp.common.lov;

import lombok.Data;

@Data
public class LovKey {

	private final String keyName;

	public LovKey(String ketName) {
		this.keyName = ketName;
	}

}
