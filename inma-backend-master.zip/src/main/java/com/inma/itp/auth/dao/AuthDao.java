package com.inma.itp.auth.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.auth.model.messaging.UsrAuthentRq;
import com.inma.itp.auth.model.messaging.UsrAuthentRs;
import com.inma.itp.common.messaging.MessageTemplateService;
import com.inma.itp.common.utils.Constants;

@Service
public class AuthDao {

	@Autowired
	private MessageTemplateService msgTemplateService;

	public Optional<UsrAuthentRs> login(UsrAuthentRq rq) {
		rq.setFuncId(Constants.FUNCTION_AUTHENT);
		return msgTemplateService.sendMessage(rq, UsrAuthentRs.class);
	}
}
