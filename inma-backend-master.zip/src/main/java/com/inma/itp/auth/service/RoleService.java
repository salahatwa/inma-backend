package com.inma.itp.auth.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.auth.model.domain.Role;
import com.inma.itp.auth.repository.RoleRepository;
import com.inma.itp.auth.repository.RoleRepository;

@Service
public class RoleService {
	@Autowired
	private RoleRepository roleRepo;

	/**
	 * Check if role already exist , if role already exist return role to user ,
	 * else create new Role
	 * 
	 * @param name
	 * @return
	 */
	@Transactional
	public Role findRole(String name) {
		Optional<Role> role = roleRepo.findByName(name);
		if (role.isPresent())
			return role.get();
		else {
			return roleRepo.save(new Role(name));
		}

	}

}
