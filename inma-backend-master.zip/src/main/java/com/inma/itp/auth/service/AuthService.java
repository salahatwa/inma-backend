package com.inma.itp.auth.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.inma.itp.auth.dao.AuthDao;
import com.inma.itp.auth.model.domain.User;
import com.inma.itp.auth.model.dto.UserData;
import com.inma.itp.auth.model.messaging.UsrAuthentRq;
import com.inma.itp.auth.model.messaging.UsrAuthentRs;
import com.inma.itp.auth.model.messaging.UsrAuthentRs.RoleInfo;
import com.inma.itp.common.exceptions.BadRequestException;
import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.messaging.MessageValidationHelper;
import com.inma.itp.common.security.JwtTokenProvider;
import com.inma.itp.common.security.RSAService;
import com.inma.itp.common.security.UserPrincipal;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.common.utils.Security;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AuthService {

	@Autowired
	private AuthDao authDao;

	@Autowired
	private UserService userService;

	@Autowired
	private JwtTokenProvider tokenProvider;

	@Autowired
	private RoleService roleService;

	@Autowired
	private RSAService rsaService;

	public UserData login(String username, String password) {
		UsrAuthentRq rq = new UsrAuthentRq();
		rq.setLoginAttribVal(username);
		rq.setLoginAttribType(Constants.AUTHENT_ATTR_TYPE);
		String decPassword;
		try {
			decPassword = rsaService.decrypt(password);
		} catch (Exception e) {
			throw new BadRequestException("secuirty issue occured during decryption");
		}
		rq.setInfo(Security.byteToHex(Security.getHash(decPassword)));
		rq.setInfoType(Constants.AUTHENT_INFO_TYPE);
		UsrAuthentRs rs = authDao.login(rq).orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));
		if (MessageValidationHelper.isValidResponse(rs)) {
			User user = new User();
			user.setId(rs.getUsrId());
			user.setLang(rs.getLangPref());
			user.setDeptCode(rs.getDeptCode());
			user.setNumOfFailedLogins(rs.getNumOfFailedLogins());
			List<RoleInfo> roles = rs.getRoles();
			for (RoleInfo role : roles) {
				user.getRoles().add(roleService.findRole(role.getRoleId()));
			}
			userService.saveUser(user);
			Authentication authentication = new UsernamePasswordAuthenticationToken(UserPrincipal.create(user),
					password, new ArrayList<>());
			SecurityContextHolder.getContext().setAuthentication(authentication);
			UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
			String jwt = tokenProvider.generateToken(authentication);
			return new UserData(jwt, userPrincipal);
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	/**
	 * Get current loggedin user
	 * 
	 * @param authorization
	 * @return
	 */
	public UserData getCurrentLoggedInUser(UserPrincipal currentUser, String authorization) {
		UserData userData = new UserData(getJwtFromRequest(authorization), currentUser);
		log.info("Current logged in user" + userData.getProfile().getId());
		return userData;
	}

	private String getJwtFromRequest(String bearerToken) {
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7, bearerToken.length());
		}
		return null;
	}

}
