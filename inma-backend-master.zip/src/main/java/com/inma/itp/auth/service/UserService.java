package com.inma.itp.auth.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.inma.itp.auth.model.domain.User;
import com.inma.itp.auth.repository.UserRepository;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.security.UserPrincipal;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {

	@Autowired
	private UserRepository userRepo;

	/**
	 * ehcache implementation for first time it will get user from db
	 * second time will get user from cache
	 * @param id
	 * @return
	 */
	@Cacheable(value = "userCache", key = "#id")
	public UserDetails getUserById(String id) {
		User user = userRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("User", "id", id));

		return UserPrincipal.create(user);
	}

	/**
	 * Save user to db
	 * @param user
	 */
	@Transactional
	public void saveUser(User user) {
		if (!userRepo.findById(user.getId()).isPresent())
			userRepo.save(user);
	}
	
	@CacheEvict(cacheNames = {"userCache"}, allEntries = true)
    public void resetUserCache() {
		log.info(">>>>>>>>>>>>> reset userCache");
    }
}
