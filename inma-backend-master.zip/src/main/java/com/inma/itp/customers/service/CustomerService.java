package com.inma.itp.customers.service;

import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.exceptions.BadRequestException;
import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.lov.LOVInqRs;
import com.inma.itp.common.lov.LOVInqRs.LOVInfo;
import com.inma.itp.common.lov.LovRequestDto;
import com.inma.itp.common.lov.LovService;
import com.inma.itp.common.messaging.MessageValidationHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.customers.dao.CustomerDao;
import com.inma.itp.customers.model.dto.CustDtlsInqDto;
import com.inma.itp.customers.model.messaging.CustDtlsInqRq;
import com.inma.itp.customers.model.messaging.CustDtlsInqRs;

@Service
public class CustomerService {
	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private LovService lovService;

	public CustDtlsInqDto getCustomerDetailsByPoiOrCif(String userId, String poiNum, String cif) {

		if (Objects.isNull(poiNum) && Objects.isNull(cif))
			throw new BadRequestException("INVALID REQUEST");

		CustDtlsInqRq request = new CustDtlsInqRq();

		if (Objects.nonNull(poiNum))
			request.setPoiNum(poiNum);

		if (Objects.nonNull(cif))
			request.setCif(cif);

		request.setAgentId(userId);
		CustDtlsInqRs rs = customerDao.getCustomerDetails(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			CustDtlsInqDto dto = new CustDtlsInqDto();
			BeanUtils.copyProperties(rs, dto);

			// LOV for Address_Type
			Optional<LOVInqRs> addressTypeList = lovService.inquiryLov(new LovRequestDto(Constants.LOV_ADDRESS_TYPE));
			if (addressTypeList.isPresent()) {
				Optional<LOVInfo> lovData = addressTypeList.get().getLovInfo().stream()
						.filter(lovInfo -> lovInfo.getRecTypeCode().equalsIgnoreCase(dto.getAddrType())).findFirst();
				if (lovData.isPresent()) {
					dto.setAddrType(lovData.get().getAttribute1() + "-" + lovData.get().getRecDesc());
				}
			}

			// LOV for Phone_Type
			Optional<LOVInqRs> phoneTypeList = lovService.inquiryLov(new LovRequestDto(Constants.LOV_PHONE_TYPE));
			if (phoneTypeList.isPresent()) {
			dto.getPhoneList().forEach(phone -> {
				Optional<LOVInfo> lovData=phoneTypeList.get().getLovInfo().stream()
					.filter(lovInfo -> lovInfo.getRecTypeCode().equalsIgnoreCase(phone.getPhoneType())).findFirst();
				
				if (lovData.isPresent()) {
					phone.setPhoneType(lovData.get().getRecDesc());
				}
				
				});
			}

			return dto;

		} else
			throw new MqException(rs.getStatusCode());
	}


}
