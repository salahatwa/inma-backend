package com.inma.itp.customers.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.messaging.MessageTemplateService;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.customers.model.messaging.CustDtlsInqRq;
import com.inma.itp.customers.model.messaging.CustDtlsInqRs;

@Service
public class CustomerDao {

	@Autowired
	private MessageTemplateService msgTemplateService;

	/**
	 * Get Customer details by CIF number or POI number
	 */
	public Optional<CustDtlsInqRs> getCustomerDetails(CustDtlsInqRq rq) {

		rq.setFuncId(Constants.FUNCTION_CUSTOMER_INQ);
		Optional<CustDtlsInqRs> rs = msgTemplateService.sendMessage(rq, CustDtlsInqRs.class);

		return rs;
	}

}
