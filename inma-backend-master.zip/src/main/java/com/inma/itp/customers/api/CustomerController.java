package com.inma.itp.customers.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.inma.itp.common.annotations.CurrentUser;
import com.inma.itp.common.security.UserPrincipal;
import com.inma.itp.customers.model.dto.CustDtlsInqDto;
import com.inma.itp.customers.service.CustomerService;

/**
 * Api to return Customers details
 * 
 * @author ssatwa
 *
 */
@RestController
@RequestMapping("${api.context.path}/customer")
@Validated
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	/**
	 * Get Customer details by POI number or CIF number
	 */
	@GetMapping("/details")
	public ResponseEntity<CustDtlsInqDto> getCustomerDetails(@CurrentUser UserPrincipal currentUser,
			@RequestParam(name = "poiNumber", required = false) String poiNumber,
			@RequestParam(name = "cif", required = false) String cif) {

		return ResponseEntity.ok(customerService.getCustomerDetailsByPoiOrCif(currentUser.getId(), poiNumber, cif));
	}

}
