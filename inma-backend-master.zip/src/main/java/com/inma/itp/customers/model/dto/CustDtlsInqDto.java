package com.inma.itp.customers.model.dto;

import java.util.ArrayList;
import java.util.List;

import com.inma.itp.customers.model.messaging.CustDtlsInqRs.PhoneInfo;

import lombok.Data;

@Data
public class CustDtlsInqDto {

	private String cif;

	private String fatherName;

	private String gender;

	private String residenceCountryCode;

	private String city;

	private String nextKYCReviewDt;

	private String poiIssueDt;

	private String grandFatherName;

	private String postalCode;

	private List<PhoneInfo> phoneList = new ArrayList<PhoneInfo>();

	private String samaStatus;

	private String birthPlace;

	private String poBox;

	private String poiIssueDtHjr;

	private String nationalityCode;

	private String relMngrId;

	private String relMngrNameEn;

	private String countryCode;

	private String isPrimary;

	private String familyName;

	private String segment;

	private String sector;

	private String email;

	private String addrType;

	private String branchId;

	private String birthDt;

	private String nextKYCReviewDtHjr;

	private String legalStatus;

	private String fullName;

	private String rqUID;

	private String poiExpDtHjr;

	private String poiExpDt;

	private String relMngrNameAr;

	private String poiIssuePlace;

	private String firstName;

	private String langPref;

	private String addrLine2;

	private String poiNum;

	private String poiType;

	private String custType;

	private String openDtHjr;

	private String openDt;

	private String shortName;

	private String maritalStatus;

	private String alinmaId;

	private String custStatus;

	@Data
	public static class PhoneList {
		private String phoneType;

		private String phoneCountryCode;

		private String phoneNum;

		private String phoneCategory;

		private String phoneAreaCode;
	}
}
