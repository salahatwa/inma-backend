package com.inma.itp.customers.model.messaging;

import javax.xml.bind.annotation.XmlRootElement;

import com.inma.itp.common.annotations.InmaQueue;
import com.inma.itp.common.model.messaging.QueueReqMsg;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@XmlRootElement(name = "CustDtlsInqRq")
@InmaQueue(requestQueue = "CustDtlsInqRq", responseQueue = "CustDtlsInqRs")
public class CustDtlsInqRq extends QueueReqMsg {

	public CustDtlsInqRq(String funcId, String agentId) {
		super(funcId);
		this.setAgentId(agentId);
	}
}
