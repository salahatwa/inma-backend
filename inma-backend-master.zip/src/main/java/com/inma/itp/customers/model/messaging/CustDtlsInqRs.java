package com.inma.itp.customers.model.messaging;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.eclipse.persistence.oxm.annotations.XmlPath;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.inma.itp.common.model.messaging.QueueResMsg;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@XmlRootElement(name = "CustDtlsInqRs")
public class CustDtlsInqRs extends QueueResMsg {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@XmlPath("Body/CIF/text()")
	private String cif;

	@XmlPath("Body/AlinmaId/text()")
	private String alinmaId;
	@XmlPath("Body/CustType/text()")
	private String custType;

	@XmlPath("Body/POIRec/POI/POINum/text()")
	private String poiNum;

	@XmlPath("Body/POIRec/POI/POIType/text()")
	private String poiType;

	@XmlPath("Body/POIRec/POIIssueDt/text()")
	private String poiIssueDt;

	@XmlPath("Body/POIRec/POIIssueDtHjr/text()")
	private String poiIssueDtHjr;

	@XmlPath("Body/POIRec/POIIssuePlace/text()")
	private String poiIssuePlace;

	@XmlPath("Body/POIRec/POIExpDt/text()")
	private String poiExpDt;

	@XmlPath("Body/POIRec/POIExpDtHjr/text()")
	private String poiExpDtHjr;

	@XmlPath("Body/FirstName/text()")
	private String firstName;

	@XmlPath("Body/FatherName/text()")
	private String fatherName;

	@XmlPath("Body/GrandFatherName/text()")
	private String grandFatherName;

	@XmlPath("Body/ShortName/text()")
	private String shortName;

	@XmlPath("Body/FamilyName/text()")
	private String familyName;

	@XmlPath("Body/FullName/text()")
	private String fullName;

	@XmlPath("Body/LangPref/text()")
	private String langPref;

	@XmlPath("Body/Gender/text()")
	private String gender;

	@XmlPath("Body/NextKYCReviewDtHjr/text()")
	private String nextKYCReviewDtHjr;

	@XmlPath("Body/BirthPlace/text()")
	private String birthPlace;

	@XmlPath("Body/Email/text()")
	private String email;

	@XmlPath("Body/NationalityCode/text()")
	private String nationalityCode;

	@XmlPath("Body/BirthDt/text()")
	private String birthDt;

	@XmlPath("Body/Segment/text()")
	private String segment;

	@XmlPath("Body/OpenDtHjr/text()")
	private String openDtHjr;

	@XmlPath("Body/ResidenceCountryCode/text()")
	private String residenceCountryCode;

	@XmlPath("Body/Sector/text()")
	private String sector;

	@XmlPath("Body/SAMAStatus/text()")
	private String samaStatus;

	@XmlPath("Body/LegalStatus/text()")
	private String legalStatus;

	@XmlPath("Body/CustStatus/text()")
	private String custStatus;

	@XmlPath("Body/BranchId/text()")
	private String branchId;

	@XmlPath("Body/MaritalStatus/text()")
	private String maritalStatus;

	@XmlPath("Body/OpenDt/text()")
	private String openDt;

	@XmlPath("Body/NextKYCReviewDt/text()")
	private String nextKYCReviewDt;

	@XmlPath("Body/AddrInfo/POBox/text()")
	private String poBox;

	@XmlPath("Body/AddrInfo/AddrLine2/text()")
	private String addrLine2;

	@XmlPath("Body/AddrInfo/AddrType/text()")
	private String addrType;

	@XmlPath("Body/AddrInfo/PostalCode/text()")
	private String postalCode;

	@XmlPath("Body/AddrInfo/City/text()")
	private String city;

	@XmlPath("Body/AddrInfo/CountryCode/text()")
	private String countryCode;

	@XmlPath("Body/RelMngrInfo/RelMngrNameEn/text()")
	private String relMngrNameEn;

	@XmlPath("Body/RelMngrInfo/RelMngrId/text()")
	private String relMngrId;

	@XmlPath("Body/RelMngrInfo/IsPrimary/text()")
	private String isPrimary;

	@XmlPath("Body/RelMngrInfo/RelMngrNameAr/text()")
	private String relMngrNameAr;

	@XmlPath("Body/PhoneInfo")
	@JacksonXmlElementWrapper(useWrapping = false)
	private List<PhoneInfo> phoneList = new ArrayList<>();

	@Data
	@NoArgsConstructor
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class PhoneInfo implements Serializable {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@XmlElement(name = "PhoneCountryCode")
		private String phoneCountryCode;

		@XmlElement(name = "PhoneType")
		private String phoneType;

		@XmlElement(name = "PhoneNum")
		private String phoneNum;

		@XmlElement(name = "PhoneCategory")
		private String phoneCategory;

		@XmlElement(name = "PhoneAreaCode")
		private String phoneAreaCode;

	}
}
