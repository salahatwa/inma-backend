package com.inma.itp.portfolio.api;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inma.itp.common.annotations.CurrentUser;
import com.inma.itp.common.security.UserPrincipal;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.portfolio.model.dto.PortfolioDetailsDto;
import com.inma.itp.portfolio.service.PortfolioService;

/**
 * Api to return Portfolio details
 * 
 * @author ssatwa,hmkhalil
 *
 */
@RestController
@RequestMapping("${api.context.path}/portfolio")
@Validated
public class PortfolioController {

	@Autowired
	private PortfolioService portfolioService;

	/**
	 * Get all portfolio details by stock number and Portfolio number
	 * 
	 * @param currentUser
	 * @param stockSymbol
	 * @param portfolioNum
	 * @return portfolio details
	 */
	@GetMapping("/{stockSymbol}/{portfolioNumber}/details")
	public ResponseEntity<PortfolioDetailsDto> getPortfolioDetailsByStockAndPortfolioNumber(
			@CurrentUser UserPrincipal currentUser,
			@NotBlank(message = Constants.STOCK_SYMBOL_REQUIRED_MSG) @Digits(fraction = 0, integer = 10, message = Constants.STOCK_SYMBOL_DIGITS_ONLY_MSG) @PathVariable("stockSymbol") String stockSymbol,
			@NotBlank(message = Constants.PORTFOLIO_NUMBER_REQUIRED_MSG) @PathVariable("portfolioNumber") String portfolioNumber) {

		return ResponseEntity.ok(portfolioService.getPortfolioDetailsByStockAndPortfolioNumber(currentUser.getId(),
				stockSymbol, portfolioNumber));
	}

	/**
	 * Get all portfolios details for given POI Number
	 * 
	 * @param currentUser
	 * @param poiNumber
	 * @return List of portfolios details
	 */
	@GetMapping("/{poiNumber}/localPortfolios")
	public ResponseEntity<List<PortfolioDetailsDto>> getLocalPortfoliosForPoiNumber(@CurrentUser UserPrincipal currentUser,
			@Digits(fraction = 0, integer = 10, message = Constants.POI_DIGITS_ONLY_MSG) @Length(max = 10, min = 10, message = Constants.POI_LENGTH_MSG) @NotBlank(message = Constants.POI_REQUIRED_MSG) @PathVariable("poiNumber") String poiNumber) {

		return ResponseEntity.ok(portfolioService.getLocalPortfoliosForPoiNumber(currentUser.getId(), poiNumber));
	}

	/**
	 * Get portfolio details by portfolio number
	 * 
	 * @param currentUser
	 * @param portfolioNumber
	 * @return
	 */
	@GetMapping("/{portfolioNumber}/details")
	public ResponseEntity<PortfolioDetailsDto> getPortfolioDetailsByPortfolioNumber(@CurrentUser UserPrincipal currentUser,
			@NotBlank(message = Constants.PORTFOLIO_NUMBER_REQUIRED_MSG) @PathVariable("portfolioNumber") String portfolioNumber) {

		return ResponseEntity
				.ok(portfolioService.getPortfolioDetailsByPortfolioNumber(currentUser.getId(), portfolioNumber));
	}

}
