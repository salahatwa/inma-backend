package com.inma.itp.portfolio.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageValidationHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.portfolio.dao.PortfolioDao;
import com.inma.itp.portfolio.model.dto.PortfolioDetailsDto;
import com.inma.itp.portfolio.model.dto.PortfolioDetailsDto.TradeSec;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRq;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRs;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRs.PortfolioDtls;

@Service
public class PortfolioService {
	@Autowired
	private PortfolioDao portfolioDao;

	public PortfolioDetailsDto getPortfolioDetailsByStockAndPortfolioNumber(String userId, String stockSymbol,
			String portfolioNumber) {

		ETradeCustPortfoliosInqRq request = new ETradeCustPortfoliosInqRq();
		request.setPortfolioNum(portfolioNumber);
		request.setPortfolioType(Constants.PORTFOLIO_TYPE);
		request.setSymbol(stockSymbol);
		request.setAgentId(userId);
		ETradeCustPortfoliosInqRs rs = portfolioDao.getPortfolioDetails(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			return Optional.ofNullable(rs.getPortfolioDtls()).filter(p -> p.size() > 0)
					.map(p -> convertPortfolioDtlsToPortfolioDetailsDto(rs.getPortfolioDtls().get(0)))
					.orElseThrow(() -> new ResourceNotFoundException(Constants.PORTFOLIO_NOTFOUND_MSG));

		} else
			throw new MqException(rs.getStatusCode());
	}

	/**
	 * Get all portfolios details for given POI Number
	 * 
	 * @param currentUser
	 * @param poiNumber
	 * @return List of portfolios details
	 */
	public List<PortfolioDetailsDto> getLocalPortfoliosForPoiNumber(String userId, String poiNumber) {

		ETradeCustPortfoliosInqRq request = new ETradeCustPortfoliosInqRq();
		request.setAgentId(userId);
		request.setPoiNum(poiNumber);
		ETradeCustPortfoliosInqRs rs = portfolioDao.getAllPortfolioDetailsForPoiNumber(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {

			return Optional.ofNullable(rs.getPortfolioDtls()).filter(p -> p.size() > 0)
					.map(p -> rs.getPortfolioDtls().stream()
							.map(portfolioDtls -> convertPortfolioDtlsToPortfolioDetailsDto(portfolioDtls))
							.collect(Collectors.toList()))
					.orElseThrow(() -> new ResourceNotFoundException(Constants.POI_HAS_NOT_PORTFOLIOS));

		} else
			throw new MqException(rs.getStatusCode());

	}

	public PortfolioDetailsDto getPortfolioDetailsByPortfolioNumber(String userId, String portfolioNumber) {

		ETradeCustPortfoliosInqRq request = new ETradeCustPortfoliosInqRq();
		request.setPortfolioNum(portfolioNumber);
		request.setPortfolioType(Constants.PORTFOLIO_TYPE);
		request.setAgentId(userId);
		ETradeCustPortfoliosInqRs rs = portfolioDao.getPortfolioDetails(request)
				.orElseThrow(() -> new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			return Optional.ofNullable(rs.getPortfolioDtls()).filter(p -> p.size() > 0)
					.map(p -> convertPortfolioDtlsToPortfolioDetailsDto(rs.getPortfolioDtls().get(0)))
					.orElseThrow(() -> new ResourceNotFoundException(Constants.PORTFOLIO_NOTFOUND_MSG));

		} else
			throw new MqException(rs.getStatusCode());
	}

	private PortfolioDetailsDto convertPortfolioDtlsToPortfolioDetailsDto(PortfolioDtls model) {
		PortfolioDetailsDto dto = new PortfolioDetailsDto();
		BeanUtils.copyProperties(model, dto);
		dto.setAcctNum(model.getAcctId().getAcctNum());
		if (model.getTradeSecList() != null && !model.getTradeSecList().isEmpty()) {
			dto.setTradeSecList(new ArrayList<TradeSec>());
			dto.setTradeSecList(model.getTradeSecList().stream().map(tardeSec -> {
				PortfolioDetailsDto.TradeSec tradeSecDto = new PortfolioDetailsDto.TradeSec();
				BeanUtils.copyProperties(tardeSec, tradeSecDto);
				return tradeSecDto;
			}).filter(tradeSec -> tradeSec.getSymbol() != null && !tradeSec.getSymbol().isEmpty()).collect(Collectors.toList()));
		}

		return dto;
	}

}
