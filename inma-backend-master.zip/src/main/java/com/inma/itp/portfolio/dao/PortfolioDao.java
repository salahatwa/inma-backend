package com.inma.itp.portfolio.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.messaging.MessageTemplateService;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRq;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRs;

@Service
public class PortfolioDao {

	@Autowired
	private MessageTemplateService msgTemplateService;

	/**
	 * Get all portfolio details by stock number and portfolio number
	 * 
	 * @param currentUser
	 * @param stockSymbol
	 * @param portfolioNum
	 * @return portfolio details
	 */
	public Optional<ETradeCustPortfoliosInqRs> getPortfolioDetails(ETradeCustPortfoliosInqRq rq) {

		rq.setFuncId(Constants.FUNCTION_PORTFOLIO_INQ);
		Optional<ETradeCustPortfoliosInqRs> rs = msgTemplateService.sendMessage(rq, ETradeCustPortfoliosInqRs.class);

		return rs;
	}

	/**
	 * Get all portfolios details for given POI Number
	 * 
	 * @param currentUser
	 * @param poiNumber
	 * @return List of portfolios details
	 */
	public Optional<ETradeCustPortfoliosInqRs> getAllPortfolioDetailsForPoiNumber(ETradeCustPortfoliosInqRq rq) {

		rq.setFuncId(Constants.FUNCTION_PORTFOLIO_POI_INQ);
		Optional<ETradeCustPortfoliosInqRs> rs = msgTemplateService.sendMessage(rq, ETradeCustPortfoliosInqRs.class);

		return rs;
	}

}
