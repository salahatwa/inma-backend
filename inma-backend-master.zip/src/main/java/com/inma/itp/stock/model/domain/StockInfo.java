package com.inma.itp.stock.model.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

/**
 * SELECT symbol, previousclosed, todaysopen, minprice, maxprice, BESTBIDPRICE,
 * BESTBIDQUANTITY, BESTASKPRICE, BESTASKQUANTITY FROM esp_todays_snapshots
 * WHERE exchangecode = 'TDWL' and symbol='1020'
 * 
 * @author ssatwa
 *
 */
@Data

//@ToString
@Entity
@Table(name = "ESP_TODAYS_SNAPSHOTS", schema = "MUBASHER_PRICE")
public class StockInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private StockId id;

	@Column(name = "previousclosed")
	private String previousClosed;

	@Column(name = "todaysopen")
	private String todaysOpen;

	@Column(name = "minprice")
	private Double minPrice;

	@Column(name = "maxprice")
	private Double maxPrice;

	@Column(name = "BESTBIDPRICE")
	private Double bestBidPrice;

	@Column(name = "BESTBIDQUANTITY")
	private Double bestBidQty;

	@Column(name = "BESTASKPRICE")
	private Double bestAskPrice;

	@Column(name = "BESTASKQUANTITY")
	private Double bestAskQty;

	@Column(name = "LASTTRADEPRICE")
	private Double price;

	@Column(name = "CHANGE")
	private Double change;

	@Column(name = "PERCENTCHANGED")
	private Double precentChanged;

}
