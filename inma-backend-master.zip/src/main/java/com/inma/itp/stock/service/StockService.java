package com.inma.itp.stock.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageValidationHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.stock.dao.StockDao;
import com.inma.itp.stock.model.domain.StockId;
import com.inma.itp.stock.model.domain.StockInfo;
import com.inma.itp.stock.model.dto.StockDetails;
import com.inma.itp.stock.model.messaging.SecsInqRq;
import com.inma.itp.stock.model.messaging.SecsInqRs;
import com.inma.itp.stock.model.messaging.SecsInqRs.SecRec;
import com.inma.itp.stock.repository.StockRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class StockService {

	@Autowired
	private StockDao stockDao;

	@Autowired
	private StockRepository stockRepository;

	/**
	 * The way the Spring cache abstraction works however is by proxying your class
	 * (using Spring AOP). However, calls to methods within the same class will not
	 * call the proxied logic, but the direct business logic beneath. This means
	 * caching does not work if you're calling methods in the same bean.
	 * 
	 * refer to link
	 * https://stackoverflow.com/questions/39072235/spring-boot-caching-in-service-class-does-not-work/39072457
	 */
	@Autowired
	private StockService stockService;

	/**
	 * Getting stock from queue (queue cache expire after one hour)
	 * 
	 * After getting secsInfo from queue Get stock details from db (db cache expire
	 * 10 seconds) update stock details with real time data fetched from db
	 * 
	 * @param userId
	 * @param symbol
	 * @return
	 */
	public StockDetails getStockDetails(String userId, String symbol, String type) {

		SecsInqRs rs = stockService.getStockBySymbolFromQueue(userId, symbol).orElseThrow(()->new MqException(Constants.STATUS_CODE_INVALID_RESPONSE));

		if (MessageValidationHelper.isValidResponse(rs)) {
			StockDetails stockDetails = new StockDetails();

			List<SecRec> recs=rs.getSecRec();
			Optional.ofNullable(recs).orElseThrow(() -> new ResourceNotFoundException("Stock Not found"));

			BeanUtils.copyProperties(recs.get(0), stockDetails);

			StockInfo stockInfo = stockService.getStockBySymbolFromDb(symbol, type)
					.orElseThrow(() -> new ResourceNotFoundException("Stock Not found"));

			stockDetails.setBestAskPrice(stockInfo.getBestAskPrice() + "");
			stockDetails.setBestAskQty(stockInfo.getBestAskQty() + "");
			stockDetails.setLastPrice(stockInfo.getPrice() + "");
			stockDetails.setBestBidPrice(stockInfo.getBestBidPrice() + "");
			stockDetails.setBestBidQty(stockInfo.getBestAskPrice() + "");
			stockDetails.setOpenPrice(stockInfo.getTodaysOpen());
			stockDetails.setPrevClosure(stockInfo.getPreviousClosed());
			stockDetails.setMaxPriceLimit(stockInfo.getMaxPrice() + "");
			stockDetails.setMinPriceLimit(stockInfo.getMinPrice() + "");
			stockDetails.setPriceChangeAmt(stockInfo.getChange() + "");
			stockDetails.setPriceChangeRate(stockInfo.getPrecentChanged() + "");

			return stockDetails;
		} else {
			throw new MqException(rs.getStatusCode());
		}
	}

	/**
	 * Get stock details from queue
	 * 
	 * @param userId
	 * @param symbol
	 * @return
	 */
	@Cacheable(value = "stockQueueCache", key = "#symbol")
	public Optional<SecsInqRs> getStockBySymbolFromQueue(String userId, String symbol) {
		log.info("Getting stock details from queue");
		SecsInqRq request = new SecsInqRq();
		request.setProductCode(Constants.PRODUCT_CODE);
		request.setSymbol(symbol);

		Optional<SecsInqRs> rs = stockDao.getStockDetails(request, userId);
		return rs;
	}

	/**
	 * look at stockDbCache in ehcache.xml Cache will expire after 10 seconds
	 * 
	 * @param symbol
	 * @return
	 */
	@Cacheable(value = "stockDbCache", key = "{#symbol,#type}")
	public Optional<StockInfo> getStockBySymbolFromDb(String symbol, String type) {
		log.info("Getting stock details from db");
		return stockRepository.findById(new StockId(symbol, type));
	}
	
	
	public List<StockInfo> getAllStocks() {
		return stockRepository.findAll();
	}

}
