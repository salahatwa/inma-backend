package com.inma.itp.stock.model.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class StockId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "EXCHANGECODE")
	private String exchangeCode;

	@Column(name = "SYMBOL")
	private String symbol;

	public StockId() {
	}

	public StockId(String symbol,String exchangeCode) {
		this.symbol = symbol;
		this.exchangeCode = exchangeCode;
	}
}