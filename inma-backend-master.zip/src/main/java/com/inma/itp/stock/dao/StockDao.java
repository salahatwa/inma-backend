package com.inma.itp.stock.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inma.itp.common.messaging.MessageTemplateService;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.stock.model.messaging.SecsInqRq;
import com.inma.itp.stock.model.messaging.SecsInqRs;

@Service
public class StockDao {

	@Autowired
	private MessageTemplateService msgTemplateService;

	public Optional<SecsInqRs> getStockDetails(SecsInqRq rq, String userId) {
		rq.setFuncId(Constants.FUNCTION_SEC);
		rq.setAgentId(userId);
		Optional<SecsInqRs> rs = msgTemplateService.sendMessage(rq, SecsInqRs.class);

		return rs;
	}
}
