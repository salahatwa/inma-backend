package com.inma.itp.stock.api;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inma.itp.common.annotations.CurrentUser;
import com.inma.itp.common.security.UserPrincipal;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.stock.model.dto.StockDetails;
import com.inma.itp.stock.service.StockService;

/**
 * Api to return stock details by stock symbol
 * 
 * @author ssatwa
 *
 */
@RestController
@RequestMapping("${api.context.path}/stock")
@Validated
public class StockController {

	@Autowired
	private StockService stockService;

	/**
	 * 
	 * @param currentUser
	 * @param symbol
	 * @param type        should be TDWL to get latest update from db or TDWL* For
	 *                    not updated
	 * @return
	 */
	@GetMapping("/{symbol}/details/{type}")
	public ResponseEntity<StockDetails> getStockDetails(@CurrentUser UserPrincipal currentUser,
			@PathVariable("symbol") @NotBlank(message = Constants.PARAM_REQUIRED) String symbol, 
			@PathVariable("type") @NotBlank(message = Constants.PARAM_REQUIRED) String type) {
		return ResponseEntity.ok(stockService.getStockDetails(currentUser.getId(), symbol, type));
	}
}
