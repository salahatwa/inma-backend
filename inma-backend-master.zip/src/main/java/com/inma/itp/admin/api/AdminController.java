package com.inma.itp.admin.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inma.itp.auth.service.UserService;

@RestController
@RequestMapping("${api.context.path}/admin")
public class AdminController {

	@Autowired
	UserService userService;

	@GetMapping("/resetUserCache")
	public void resetUserCache() {
		userService.resetUserCache();
	}
}
