package com.inma.itp.test.unittest.common;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

import com.inma.itp.auth.model.messaging.UsrAuthentRq;
import com.inma.itp.auth.model.messaging.UsrAuthentRs;
import com.inma.itp.common.messaging.MessageSerializerHelper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JaxbTest extends BaseUnitTest {

	@Test
	public void marchalling() {
		UsrAuthentRq rq = new UsrAuthentRq();
		String rqMsg = MessageSerializerHelper.serializeToXML(rq);
		log.info("Marchalling:{}", rqMsg);
		assertThat(rqMsg).isNotNull();
		assertThat(rqMsg).contains("MsgRqHdr");
	}

	@Test
	public void unmarchalling() {
		String msg = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><UsrAuthentRs><MsgRsHdr><StatusCode>I000000</StatusCode><RqUID>ITPa0146b1c681944368403392207cf13ce</RqUID></MsgRsHdr><Body><OneTmPswdFlg>N</OneTmPswdFlg><BankUsrInfo><UsrId>BKF_USR_1621</UsrId><LangPref>En</LangPref><NumOfFailedLogins>0</NumOfFailedLogins><LastLoginTmstmp>2020-05-07 05:26:15</LastLoginTmstmp><RoleInfo><RoleId>901</RoleId></RoleInfo><RoleInfo><RoleId>902</RoleId></RoleInfo><RoleInfo><RoleId>903</RoleId></RoleInfo><RoleInfo><RoleId>904</RoleId></RoleInfo><RoleInfo><RoleId>905</RoleId></RoleInfo><RoleInfo><RoleId>906</RoleId></RoleInfo><RoleInfo><RoleId>907</RoleId></RoleInfo><RoleInfo><RoleId>908</RoleId></RoleInfo><RoleInfo><RoleId>909</RoleId></RoleInfo><RoleInfo><RoleId>910</RoleId></RoleInfo><RoleInfo><RoleId>911</RoleId></RoleInfo></BankUsrInfo></Body></UsrAuthentRs>\r\n";
		UsrAuthentRs user = MessageSerializerHelper.deserializeFromXML(msg, UsrAuthentRs.class);
		log.info("Unmarchalling:{}", user);

		assertThat(user).isNotNull();
		assertThat(user.getRqUID()).isNotBlank();
	}

}
