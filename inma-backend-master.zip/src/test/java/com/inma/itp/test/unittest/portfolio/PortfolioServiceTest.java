package com.inma.itp.test.unittest.portfolio;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageSerializerHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.portfolio.dao.PortfolioDao;
import com.inma.itp.portfolio.model.dto.PortfolioDetailsDto;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRq;
import com.inma.itp.portfolio.model.messaging.ETradeCustPortfoliosInqRs;
import com.inma.itp.portfolio.service.PortfolioService;
import com.inma.itp.test.TestData;
import com.inma.itp.test.unittest.common.BaseUnitTest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PortfolioServiceTest extends BaseUnitTest {
	@Autowired
	private PortfolioService portfolioService;
	@MockBean
	private PortfolioDao portfolioDao;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();
	private String getPortfoliosByPoiMockReturnRs;
	private String getPortfolioDetailsMockReturnRs;

 
	@TestConfiguration
	static class portfolioServiceTestContextConfiguration {
		/*
		 * @Bean public PortfolioMapper portfolioMapper() { return
		 * Mappers.getMapper(PortfolioMapper.class); }
		 */
		
		@Bean
		public PortfolioService portfolioService() {
			return new PortfolioService();
		}
	}
	


	@Before
	public void setUp() {
		getAllPortfolioDetailsForPoiNumberMockSetup();
		getPortfolioDetailsByStockSymbolAndPortfolioNumberMockSetup();
		getPortfolioDetailsByPortfolioNumberMockSetup();
	}

	private void getAllPortfolioDetailsForPoiNumberMockSetup() {
		ETradeCustPortfoliosInqRq getPortfoliosByPoiRq = new ETradeCustPortfoliosInqRq();
		getPortfoliosByPoiRq.setAgentId(TestData.USER_ID);
		getPortfoliosByPoiRq.setPoiNum(TestData.POI_NUMBER);
		String getPortfoliosByPoiRsStr_Success = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeCustPortfoliosInqRs><MsgRsHdr><StatusCode>I000000</StatusCode><RqUID>ITP79dfd2fff9e547bfb4a5431705be4d23</RqUID></MsgRsHdr><Body><RecCtrlOut><MatchedRecs>7</MatchedRecs><SentRecs>5</SentRecs></RecCtrlOut><PortfoliosList><PortfolioDtls><PortfolioNum>65519-1</PortfolioNum><PortfolioType>IP</PortfolioType><PortfolioName>ALFAHAD,SALEHN</PortfolioName><AcctId><AcctNum>100065519017</AcctNum><AcctType>IN</AcctType></AcctId></PortfolioDtls><PortfolioDtls><PortfolioNum>65519-3</PortfolioNum><PortfolioType>IP</PortfolioType><PortfolioName>ALFAHAD,SALEHN</PortfolioName><AcctId><AcctNum>100065519041</AcctNum><AcctType>IN</AcctType></AcctId></PortfolioDtls><PortfolioDtls><PortfolioNum>65519-5</PortfolioNum><PortfolioType>IP</PortfolioType><PortfolioName>ALFAHAD,SALEHN</PortfolioName><SAMAAcctNum>4500014883</SAMAAcctNum><AcctId><AcctNum>100065519262</AcctNum><AcctType>IN</AcctType></AcctId></PortfolioDtls><PortfolioDtls><PortfolioNum>65519-6</PortfolioNum><PortfolioType>IP</PortfolioType><PortfolioName>ALFAHAD,SALEHN</PortfolioName><SAMAAcctNum>4500014891</SAMAAcctNum><AcctId><AcctNum>100065519270</AcctNum><AcctType>IN</AcctType></AcctId></PortfolioDtls><PortfolioDtls><PortfolioNum>65519-7</PortfolioNum><PortfolioType>IP</PortfolioType><PortfolioName>ALFAHAD,SALEHN</PortfolioName><SAMAAcctNum>4500015088</SAMAAcctNum><AcctId><AcctNum>100065519297</AcctNum><AcctType>IN</AcctType></AcctId></PortfolioDtls></PortfoliosList></Body></eTradeCustPortfoliosInqRs>";
		String getPortfoliosByPoiRsStr_Fail = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeCustPortfoliosInqRs><MsgRsHdr><StatusCode>E001177</StatusCode><RqUID>ITP988fd1cbdd584f1793db6625dc5804ee</RqUID></MsgRsHdr></eTradeCustPortfoliosInqRs>";
		ETradeCustPortfoliosInqRs getPortfoliosByPoiRs_Success = MessageSerializerHelper
				.deserializeFromXML(getPortfoliosByPoiRsStr_Success, ETradeCustPortfoliosInqRs.class);
		ETradeCustPortfoliosInqRs getPortfoliosByPoiRs_Fail = MessageSerializerHelper
				.deserializeFromXML(getPortfoliosByPoiRsStr_Fail, ETradeCustPortfoliosInqRs.class);
		ETradeCustPortfoliosInqRs getPortfoliosByPoiRs_Invalid = new ETradeCustPortfoliosInqRs();
		getPortfoliosByPoiRs_Invalid.setStatusCode(Constants.STATUS_CODE_SUCCESS);
		Mockito.when(portfolioDao.getAllPortfolioDetailsForPoiNumber(getPortfoliosByPoiRq))
				.thenAnswer(new Answer<Optional<ETradeCustPortfoliosInqRs>>() {
					@Override
					public Optional<ETradeCustPortfoliosInqRs> answer(InvocationOnMock invocation) {
						if (TestData.SUCCESS_RESPONSE.equals(getPortfoliosByPoiMockReturnRs)) {
							return Optional.ofNullable(getPortfoliosByPoiRs_Success);
						} else if (TestData.FAIL_RESPONSE.equals(getPortfoliosByPoiMockReturnRs)) {
							return Optional.ofNullable(getPortfoliosByPoiRs_Fail);
						} else if (TestData.INVALID_RESPONSE.equals(getPortfoliosByPoiMockReturnRs)) {
							return Optional.ofNullable(getPortfoliosByPoiRs_Invalid);
						} else {
							return Optional.ofNullable(null);
						}

					}
				});
	}

	private void getPortfolioDetailsByStockSymbolAndPortfolioNumberMockSetup() {
		ETradeCustPortfoliosInqRq getPortfoliosDetailsRq = new ETradeCustPortfoliosInqRq();
		getPortfoliosDetailsRq.setPortfolioNum(TestData.PORTFOLIO_NUMBER);
		getPortfoliosDetailsRq.setPortfolioType(Constants.PORTFOLIO_TYPE);
		getPortfoliosDetailsRq.setAgentId(TestData.USER_ID);
		getPortfoliosDetailsRq.setSymbol(TestData.STOCK_SYMBOL);
		getPortfolioDetailsMockSetup(getPortfoliosDetailsRq);
	}

	private void getPortfolioDetailsMockSetup(ETradeCustPortfoliosInqRq getPortfoliosDetailsRq) {
		String getPortfolioDetailsRsStr_Success = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeCustPortfoliosInqRs><MsgRsHdr><StatusCode>I000000</StatusCode><RqUID>ITP95703b3560c346a0bb311bf0fa8459ce</RqUID></MsgRsHdr><Body><RecCtrlOut><MatchedRecs>1</MatchedRecs><SentRecs>1</SentRecs></RecCtrlOut><PortfoliosList><PortfolioDtls><PortfolioNum>65519-1</PortfolioNum><PortfolioName>ALFAHAD,SALEHN</PortfolioName><SAMAAcctNum>4500012903</SAMAAcctNum><AcctId><AcctNum>100065519017</AcctNum></AcctId><PortfolioPositionAmt>12784440.27</PortfolioPositionAmt><TotalCost>39551.34</TotalCost><TotalMrktVal>9681924</TotalMrktVal><TotalUnrealizedProfitLoss>9642372.66</TotalUnrealizedProfitLoss><TotalRealizedProfitLoss>35297.47</TotalRealizedProfitLoss><DiscountRate>0</DiscountRate><MobileNum>0566806592</MobileNum><MarginLimit>0.00</MarginLimit><POINum>1035527041</POINum><AvailBal>3102516.27</AvailBal><BuyingPwr>3102516.27</BuyingPwr><OutstandBuyAmt>0</OutstandBuyAmt><OutstandSellAmt>0</OutstandSellAmt><ExcBuyAmt>0</ExcBuyAmt><ExcSellAmt>0</ExcSellAmt><TradeSecsList><TradeSec><Symbol>1020</Symbol><SecEnName>Bank AlJazira</SecEnName><SecArName>بنك الجزيرة</SecArName><OwnedQuantity>10213</OwnedQuantity><OutstandSellQuantity>0</OutstandSellQuantity><OutstandBuyQuantity>0</OutstandBuyQuantity><PledgedQuantity>0</PledgedQuantity><AvailQuantity>10213</AvailQuantity><AvgCostPrice>3.8726466268481</AvgCostPrice><MrktPrice>948.00</MrktPrice><TotalCost>39551.34</TotalCost><TotalMrktVal>9681924</TotalMrktVal><UnrealizedProfitLoss>9642372.66</UnrealizedProfitLoss><RealizedProfitLoss>35297.47</RealizedProfitLoss><UnrealizedProfitLossPercen>24379.38299941291</UnrealizedProfitLossPercen><RealizedProfitLossPercen>89.24468804343</RealizedProfitLossPercen><UnsettledBuyQuantity>2</UnsettledBuyQuantity><UnsettledSellQuantity>1</UnsettledSellQuantity></TradeSec></TradeSecsList></PortfolioDtls></PortfoliosList></Body></eTradeCustPortfoliosInqRs>";
		String getPortfolioDetailsRsStr_Fail = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeCustPortfoliosInqRs><MsgRsHdr><StatusCode>E811052</StatusCode><RqUID>ITP59cbde91232441b0ba1adbd2bcd21708</RqUID></MsgRsHdr></eTradeCustPortfoliosInqRs>";
		ETradeCustPortfoliosInqRs getPortfolioDetailsRs_Success = MessageSerializerHelper
				.deserializeFromXML(getPortfolioDetailsRsStr_Success, ETradeCustPortfoliosInqRs.class);
		ETradeCustPortfoliosInqRs getPortfolioDetailsRs_Fail = MessageSerializerHelper
				.deserializeFromXML(getPortfolioDetailsRsStr_Fail, ETradeCustPortfoliosInqRs.class);
		ETradeCustPortfoliosInqRs getPortfolioDetailsRs_Invalid = new ETradeCustPortfoliosInqRs();
		getPortfolioDetailsRs_Invalid.setStatusCode(Constants.STATUS_CODE_SUCCESS);

		Mockito.when(portfolioDao.getPortfolioDetails(getPortfoliosDetailsRq))
				.thenAnswer(new Answer<Optional<ETradeCustPortfoliosInqRs>>() {
					@Override
					public Optional<ETradeCustPortfoliosInqRs> answer(InvocationOnMock invocation) {
						if (TestData.SUCCESS_RESPONSE.equals(getPortfolioDetailsMockReturnRs)) {
							return Optional.ofNullable(getPortfolioDetailsRs_Success);
						} else if (TestData.FAIL_RESPONSE.equals(getPortfolioDetailsMockReturnRs)) {
							return Optional.ofNullable(getPortfolioDetailsRs_Fail);
						} else if (TestData.INVALID_RESPONSE.equals(getPortfolioDetailsMockReturnRs)) {
							return Optional.ofNullable(getPortfolioDetailsRs_Invalid);
						} else {
							return Optional.ofNullable(null);
						}
					}
				});
	}

	private void getPortfolioDetailsByPortfolioNumberMockSetup() {
		ETradeCustPortfoliosInqRq getPortfoliosDetailsRq = new ETradeCustPortfoliosInqRq();
		getPortfoliosDetailsRq.setPortfolioNum(TestData.PORTFOLIO_NUMBER);
		getPortfoliosDetailsRq.setPortfolioType(Constants.PORTFOLIO_TYPE);
		getPortfoliosDetailsRq.setAgentId(TestData.USER_ID);
		getPortfolioDetailsMockSetup(getPortfoliosDetailsRq);
	}

	@Test
	public void getPortfolioDetailsByStockAndPortfolioNumber_Success() {
		this.getPortfolioDetailsMockReturnRs = TestData.SUCCESS_RESPONSE;
		PortfolioDetailsDto rs = portfolioService.getPortfolioDetailsByStockAndPortfolioNumber(TestData.USER_ID,
				TestData.STOCK_SYMBOL, TestData.PORTFOLIO_NUMBER);
		assertThat(rs).isNotNull();
		assertThat(rs.getPortfolioNum()).isNotBlank();
		log.info("getPortfolioDetailsByStockAndPortfolioNumber_Success Test Case Passed : response = " + rs);

	}

	@Test(expected = MqException.class)
	public void getPortfolioDetailsByStockAndPortfolioNumber_Fail() {
		this.getPortfolioDetailsMockReturnRs = TestData.FAIL_RESPONSE;
		portfolioService.getPortfolioDetailsByStockAndPortfolioNumber(TestData.USER_ID, TestData.STOCK_SYMBOL,
				TestData.INVALID_PORTFOLIO_NUMBER);
		log.info("getPortfolioDetailsByStockAndPortfolioNumber_Fail Test Case Passed");
	}

	@Test
	public void getPortfolioDetailsByStockAndPortfolioNumber_Timeout() {
		this.getPortfolioDetailsMockReturnRs = TestData.TIMEOUT_RESPONSE;
		exceptionRule.expect(MqException.class);
		exceptionRule.expectMessage(Constants.STATUS_CODE_INVALID_RESPONSE);
		portfolioService.getPortfolioDetailsByStockAndPortfolioNumber(TestData.USER_ID, TestData.STOCK_SYMBOL,
				TestData.PORTFOLIO_NUMBER);
		log.info("getPortfolioDetailsByStockAndPortfolioNumber_Timeout Test Case Passed");
	}

	@Test(expected = ResourceNotFoundException.class)
	public void getPortfolioDetailsByStockAndPortfolioNumber_Invalid() {
		this.getPortfolioDetailsMockReturnRs = TestData.INVALID_RESPONSE;
		portfolioService.getPortfolioDetailsByStockAndPortfolioNumber(TestData.USER_ID, TestData.STOCK_SYMBOL,
				TestData.PORTFOLIO_NUMBER);
		log.info("getPortfolioDetailsByStockAndPortfolioNumber_Invalid Test Case Passed");
	}

	@Test
	public void getPortfolioDetailsByPortfolioNumber_Success() {
		this.getPortfolioDetailsMockReturnRs = TestData.SUCCESS_RESPONSE;

		PortfolioDetailsDto rs = portfolioService.getPortfolioDetailsByPortfolioNumber(TestData.USER_ID,
				TestData.PORTFOLIO_NUMBER);
		assertThat(rs).isNotNull();
		assertThat(rs.getPortfolioNum()).isNotBlank();
		log.info("getPortfolioDetailsByPortfolioNumber_Success Test Case Passed : response = " + rs);
	}

	@Test(expected = MqException.class)
	public void getPortfolioDetailsByPortfolioNumber_Fail() {
		this.getPortfolioDetailsMockReturnRs = TestData.FAIL_RESPONSE;
		portfolioService.getPortfolioDetailsByPortfolioNumber(TestData.USER_ID, TestData.INVALID_PORTFOLIO_NUMBER);
		log.info("getPortfolioDetailsByPortfolioNumber_Fail Test Case Passed");
	}

	@Test
	public void getPortfolioDetailsByPortfolioNumber_Timeout() {
		this.getPortfolioDetailsMockReturnRs = TestData.TIMEOUT_RESPONSE;
		exceptionRule.expect(MqException.class);
		exceptionRule.expectMessage(Constants.STATUS_CODE_INVALID_RESPONSE);
		portfolioService.getPortfolioDetailsByPortfolioNumber(TestData.USER_ID, TestData.PORTFOLIO_NUMBER);
		log.info("getPortfolioDetailsByPortfolioNumber_Timeout Test Case Passed");
	}

	@Test(expected = ResourceNotFoundException.class)
	public void getPortfolioDetailsByPortfolioNumber_Invalid() {
		this.getPortfolioDetailsMockReturnRs = TestData.INVALID_RESPONSE;
		portfolioService.getPortfolioDetailsByPortfolioNumber(TestData.USER_ID, TestData.PORTFOLIO_NUMBER);
		log.info("getPortfolioDetailsByPortfolioNumber_Invalid Test Case Passed");
	}

	@Test
	public void getLocalPortfoliosForPoiNumber_Success() {
		this.getPortfoliosByPoiMockReturnRs = TestData.SUCCESS_RESPONSE;
		List<PortfolioDetailsDto> rs = portfolioService.getLocalPortfoliosForPoiNumber(TestData.USER_ID,
				TestData.POI_NUMBER);
		assertThat(rs).isNotNull();
		assertThat(rs.size() > 0);
		log.info("getLocalPortfoliosForPoiNumber_Success Test Passed : response = " + rs);
	}

	@Test(expected = MqException.class)
	public void getLocalPortfoliosForPoiNumber_Fail() {
		this.getPortfoliosByPoiMockReturnRs = TestData.FAIL_RESPONSE;
		portfolioService.getLocalPortfoliosForPoiNumber(TestData.USER_ID, TestData.INVALID_POI_NUMBER);
		log.info("getLocalPortfoliosForPoiNumber_Fail Test Case Passed");
	}

	@Test
	public void getLocalPortfoliosForPoiNumber_Timeout() {
		this.getPortfoliosByPoiMockReturnRs = TestData.TIMEOUT_RESPONSE;
		exceptionRule.expect(MqException.class);
		exceptionRule.expectMessage(Constants.STATUS_CODE_INVALID_RESPONSE);
		portfolioService.getLocalPortfoliosForPoiNumber(TestData.USER_ID, TestData.POI_NUMBER);
		log.info("getLocalPortfoliosForPoiNumber_Timeout Test Case Passed");
	}

	@Test(expected = ResourceNotFoundException.class)
	public void getLocalPortfoliosForPoiNumber_Invalid() {
		this.getPortfoliosByPoiMockReturnRs = TestData.INVALID_RESPONSE;
		portfolioService.getLocalPortfoliosForPoiNumber(TestData.USER_ID, TestData.POI_NUMBER);
		log.info("getLocalPortfoliosForPoiNumber_Invalid Test Case Passed");
	}
}
