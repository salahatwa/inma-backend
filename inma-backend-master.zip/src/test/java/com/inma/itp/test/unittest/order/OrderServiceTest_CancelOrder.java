package com.inma.itp.test.unittest.order;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.messaging.MessageSerializerHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.order.dao.OrderDao;
import com.inma.itp.order.model.messaging.ETradeOrdMngRq;
import com.inma.itp.order.model.messaging.ETradeOrdMngRs;
import com.inma.itp.order.service.OrderService;
import com.inma.itp.test.TestData;
import com.inma.itp.test.unittest.common.BaseUnitTest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OrderServiceTest_CancelOrder extends BaseUnitTest {
	@Autowired
	private OrderService orderService;
	@MockBean
	private OrderDao orderDao;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	private String cancelOrderMockReturnRs;

	@TestConfiguration
	static class OrderServiceTestContextConfiguration {

		@Bean
		public OrderService orderService() {
			return new OrderService();
		}
	}

	@Before
	public void setUp() {
		cancelOrderMockSetup();

	}

	private void cancelOrderMockSetup() {
		ETradeOrdMngRq eTradeOrdMngRq = new ETradeOrdMngRq();
		eTradeOrdMngRq.setAgentId(TestData.USER_ID);
		eTradeOrdMngRq.setPortfolioNum(TestData.PORTFOLIO_NUMBER);
		eTradeOrdMngRq.setOmsRefNum(TestData.OMS_REF_NUM);
		eTradeOrdMngRq.setProduct(Constants.PRODUCT);
		String cancelOrderRsStr_Success = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeOrdMngRs><MsgRsHdr><StatusCode>I000000</StatusCode><RqUID>ITP20200531CF886F63A2B0304C</RqUID><SPRefNum>201520KHG8</SPRefNum></MsgRsHdr><Body><CustLimit/></Body></eTradeOrdMngRs>";
		String cancelOrderRsStr_Fail = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeOrdMngRs><MsgRsHdr><StatusCode>E000121</StatusCode><RqUID>ITP20200531CF886F63A2B0304C</RqUID><SPRefNum>201520KHG8</SPRefNum></MsgRsHdr><Body><CustLimit/></Body></eTradeOrdMngRs>";
		ETradeOrdMngRs cancelOrderRs_Success = MessageSerializerHelper.deserializeFromXML(cancelOrderRsStr_Success,
				ETradeOrdMngRs.class);
		ETradeOrdMngRs getOrderDetailsRs_Fail = MessageSerializerHelper.deserializeFromXML(cancelOrderRsStr_Fail,
				ETradeOrdMngRs.class);
		ETradeOrdMngRs cancelOrderRs_Invalid = new ETradeOrdMngRs();
		cancelOrderRs_Invalid.setStatusCode(Constants.STATUS_CODE_SUCCESS);
		Mockito.when(orderDao.cancelOrder(eTradeOrdMngRq)).thenAnswer(new Answer<Optional<ETradeOrdMngRs>>() {
			@Override
			public Optional<ETradeOrdMngRs> answer(InvocationOnMock invocation) {
				if (TestData.SUCCESS_RESPONSE.equals(cancelOrderMockReturnRs)) {
					return Optional.ofNullable(cancelOrderRs_Success);
				} else if (TestData.FAIL_RESPONSE.equals(cancelOrderMockReturnRs)) {
					return Optional.ofNullable(getOrderDetailsRs_Fail);
				} else if (TestData.INVALID_RESPONSE.equals(cancelOrderMockReturnRs)) {
					return Optional.ofNullable(cancelOrderRs_Invalid);
				} else {
					return Optional.ofNullable(null);
				}

			}
		});
	}

	@Test
	public void cancelOrder_Success() {
		this.cancelOrderMockReturnRs = TestData.SUCCESS_RESPONSE;
		boolean rs = orderService.cancelOrder(TestData.USER_ID, TestData.PORTFOLIO_NUMBER,
				TestData.OMS_REF_NUM);
		assertThat(rs).isNotNull();
		assertThat(rs).isTrue();

		log.info("getOrderDetails_Success Test Case Passed : response = " + rs);

	}

	@Test(expected = MqException.class)
	public void cancelOrder_Fail() {
		this.cancelOrderMockReturnRs = TestData.FAIL_RESPONSE;
		orderService.cancelOrder(TestData.USER_ID, TestData.INVALID_PORTFOLIO_NUMBER, TestData.INVALID_OMS_REF_NUM);
		log.info("getOrderDetails_Fail Test Case Passed");
	}

	@Test
	public void cancelOrder_Timeout() {
		this.cancelOrderMockReturnRs = TestData.TIMEOUT_RESPONSE;
		exceptionRule.expect(MqException.class);
		exceptionRule.expectMessage(Constants.STATUS_CODE_INVALID_RESPONSE);
		orderService.cancelOrder(TestData.USER_ID, TestData.PORTFOLIO_NUMBER, TestData.OMS_REF_NUM);
		log.info("getOrderDetails_Timeout Test Case Passed");
	}

}
