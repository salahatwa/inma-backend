package com.inma.itp.test.integrationtest.order;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.inma.itp.test.TestData;
import com.inma.itp.test.integrationtest.common.BaseIntegrationTest;

public class OrderControllerTest_GetOrderDetails extends BaseIntegrationTest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void getOrderDetailsTest_Success() throws Exception {

		mockMvc.perform(get("/api/v1/order/" + TestData.OMS_REF_NUM+"/"+TestData.PORTFOLIO_NUMBER + "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.ordStatus").isNotEmpty())
				.andDo(print());
	}
	
	@Test
	public void getOrderDetailsTest_UnAuthorized() throws Exception {

		mockMvc.perform(get("/api/v1/order/" + TestData.OMS_REF_NUM+"/"+TestData.PORTFOLIO_NUMBER + "/details").header("Authorization", "")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnauthorized())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}
	
	@Test
	public void getOrderDetailsTest_InvalidInput_BadRequest() throws Exception {

		mockMvc.perform(get("/api/v1/order/" + " "+"/"+TestData.INVALID_PORTFOLIO_NUMBER + "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}

	/*
	 * @Test public void getOrderDetailsTest_MQError_BadRequest() throws Exception {
	 * 
	 * mockMvc.perform(get("/api/v1/order/" +
	 * TestData.INVALID_OMS_REF_NUM+"/"+TestData.INVALID_PORTFOLIO_NUMBER +
	 * "/details") .header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
	 * .contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
	 * .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).
	 * andDo(print());
	 * 
	 * }
	 */

	@Test
	public void getOrderDetailsTest_OrderNotFound() throws Exception {

		mockMvc.perform(get("/api/v1/order/" + TestData.INVALID_OMS_REF_NUM+"/"+TestData.INVALID_PORTFOLIO_NUMBER +  "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isNotFound())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}
	

}
