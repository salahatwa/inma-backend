package com.inma.itp.test.integrationtest.portfolio;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.inma.itp.test.TestData;
import com.inma.itp.test.integrationtest.common.BaseIntegrationTest;

public class PortfolioControllerTest extends BaseIntegrationTest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void getPortfoliosByPoiTest_Success() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.POI_NUMBER + "/localPortfolios")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$[0].portfolioNum").isNotEmpty())
				.andDo(print());
	}

	@Test
	public void getPortfoliosByPoiTest_UnAuthorized() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.POI_NUMBER + "/localPortfolios").header("Authorization", "")
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isUnauthorized())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}
	
	@Test
	public void getPortfoliosByPoiTest_InvalidInput_BadRequest() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.INVALID_POI_NUMBER + "/localPortfolios")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}

	@Test
	public void getPortfoliosByPoiTest_MQError_BadRequest() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.INVALID_POI_NUMBER + "/localPortfolios")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}

   
	@Test
	public void getPortfolioDetailsByPortfolioNumberAndStockSymbol_Success() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.STOCK_SYMBOL + "/" + TestData.PORTFOLIO_NUMBER + "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.portfolioNum").isNotEmpty())
				.andDo(print());
	}
    
    //@Ignore
	@Test
	public void getPortfolioDetailsByPortfolioNumberAndStockSymbol_InvalidInput_BadRequest() throws Exception {

		mockMvc.perform(
				get("/api/v1/portfolio/" + TestData.INVALID_STOCK_SYMBOL + "/" + TestData.PORTFOLIO_NUMBER + "/details")
						.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andDo(print());
	}

	@Test
	public void getPortfolioDetailsByPortfolioNumberAndStockSymbol_MQError_BadRequest() throws Exception {

		mockMvc.perform(
				get("/api/v1/portfolio/" + TestData.STOCK_SYMBOL + "/" + TestData.INVALID_PORTFOLIO_NUMBER + "/details")
						.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());
	}

	@Test
	public void getPortfolioDetailsByPortfolioNumberTest_Success() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.PORTFOLIO_NUMBER + "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.portfolioNum").isNotEmpty())
				.andDo(print());
	}

    
	@Test
	public void getPortfolioDetailsByPortfolioNumberTest_MQError() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + TestData.INVALID_PORTFOLIO_NUMBER + "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());
	}

	@Test
	public void getPortfolioDetailsByPortfolioNumberTest_InvalidInput_BadRequest() throws Exception {

		mockMvc.perform(get("/api/v1/portfolio/" + " " + "/details")
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());
	}

}
