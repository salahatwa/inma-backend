package com.inma.itp.test.integrationtest.order;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.inma.itp.test.TestData;
import com.inma.itp.test.integrationtest.common.BaseIntegrationTest;

public class OrderControllerTest_CancelOrder extends BaseIntegrationTest {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void cancelOrderTest_Success() throws Exception {

		mockMvc.perform(delete("/api/v1/order/" + TestData.CANCEL_OMS_REF_NUM + "/" + TestData.PORTFOLIO_NUMBER)
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.orderDeleted").value(Boolean.TRUE)).andDo(print());
	}

	@Test
	public void cancelOrderTest_UnAuthorized() throws Exception {

		mockMvc.perform(delete("/api/v1/order/" + TestData.OMS_REF_NUM + "/" + TestData.PORTFOLIO_NUMBER)
				.header("Authorization", "").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isUnauthorized())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}

	@Test
	public void cancelOrderTest_InvalidInput_BadRequest() throws Exception {

		mockMvc.perform(delete("/api/v1/order/" + " " + "/" + TestData.INVALID_PORTFOLIO_NUMBER)
				.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}

	@Test
	public void cancelOrderTest_MQError_BadRequest() throws Exception {

		mockMvc.perform(
				delete("/api/v1/order/" + TestData.INVALID_OMS_REF_NUM + "/" + TestData.INVALID_PORTFOLIO_NUMBER)
						.header("Authorization", "Bearer " + obtainAccessToken(mockMvc))
						.contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON)).andDo(print());

	}

}
