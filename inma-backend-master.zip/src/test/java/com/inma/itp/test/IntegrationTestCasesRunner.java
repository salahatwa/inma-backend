package com.inma.itp.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.inma.itp.test.integrationtest.auth.AuthControllerTest;
import com.inma.itp.test.integrationtest.order.OrderControllerTest_GetOrderDetails;
import com.inma.itp.test.integrationtest.portfolio.PortfolioControllerTest;

/**
 * main class to run all e2e test cases
 * 
 * @author ssatwa
 *
 */
@RunWith(Suite.class)
@Suite.SuiteClasses(
		{
			AuthControllerTest.class,PortfolioControllerTest.class ,OrderControllerTest_GetOrderDetails.class
		})
public class IntegrationTestCasesRunner {

}
