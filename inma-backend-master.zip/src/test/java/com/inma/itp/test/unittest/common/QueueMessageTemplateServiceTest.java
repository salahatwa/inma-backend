package com.inma.itp.test.unittest.common;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.inma.itp.auth.model.messaging.UsrAuthentRq;
import com.inma.itp.auth.model.messaging.UsrAuthentRs;
import com.inma.itp.common.messaging.QueueMessageTemplateServiceImpl;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.common.utils.Security;
import com.inma.itp.test.TestData;
import com.inma.itp.test.integrationtest.common.BaseIntegrationTest;

public class QueueMessageTemplateServiceTest extends BaseIntegrationTest {

	@Autowired
	@Qualifier("queueMessageTemplateServiceImpl")
	private QueueMessageTemplateServiceImpl queueMessageTemplateServiceImpl;

	@Test
	public void sendAndReciveMsgQueue() {

		UsrAuthentRq rq = new UsrAuthentRq();
		rq.setLoginAttribVal(TestData.USERNAME);
		rq.setLoginAttribType(Constants.AUTHENT_ATTR_TYPE);
		rq.setInfo(Security.byteToHex(Security.getHash(TestData.PASSWORD)));
		rq.setInfoType(Constants.AUTHENT_INFO_TYPE);
		rq.setFuncId(Constants.FUNCTION_AUTHENT);
		Optional<UsrAuthentRs> rs = queueMessageTemplateServiceImpl.sendMessage(rq, UsrAuthentRs.class);
		assertThat(rs).isNotNull();
		assertThat(rs.get().getRqUID()).isNotBlank();
	}

}
