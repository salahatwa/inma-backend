package com.inma.itp.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.inma.itp.test.unittest.auth.AuthServiceTest;
import com.inma.itp.test.unittest.common.JaxbTest;
import com.inma.itp.test.unittest.common.QueueMessageTemplateServiceTest;
import com.inma.itp.test.unittest.order.OrderServiceTest_GetOrderDetails;
import com.inma.itp.test.unittest.portfolio.PortfolioServiceTest;

/**
 * main class to run all e2e test cases
 * 
 * @author ssatwa
 *
 */
@RunWith(Suite.class)
@Suite.SuiteClasses(
		{
			JaxbTest.class, QueueMessageTemplateServiceTest.class, 
			AuthServiceTest.class,PortfolioServiceTest.class,
			OrderServiceTest_GetOrderDetails.class 
		})
public class UnitTestCasesRunner {

}
