package com.inma.itp.test.integrationtest.common;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.runner.RunWith;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.inma.itp.Application;
import com.inma.itp.auth.model.dto.LoginRequest;
import com.inma.itp.test.TestData;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = Application.class)
@SpringBootTest
@ActiveProfiles("dev")
@AutoConfigureMockMvc 

public abstract class BaseIntegrationTest   {
	 static {
			System.setProperty("javax.xml.bind.context.factory", "org.eclipse.persistence.jaxb.JAXBContextFactory");
	    }
	private ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
    private String accessToken;
	public String obtainAccessToken(MockMvc mockMvc) throws Exception {
		if(accessToken != null && ! accessToken.isEmpty())
			return accessToken;
		LoginRequest request = new LoginRequest();
		request.setUsername(TestData.USERNAME);
		request.setPassword(TestData.PASSWORD);

		ResultActions result = mockMvc
				.perform(post("/api/v1/auth/login").contentType(MediaType.APPLICATION_JSON)
						.content(ow.writeValueAsString(request)))
				.andExpect(status().isOk()).andExpect(jsonPath("$.accessToken").exists()).andDo(print());

		String resultString = result.andReturn().getResponse().getContentAsString();

		JacksonJsonParser jsonParser = new JacksonJsonParser();
		accessToken = jsonParser.parseMap(resultString).get("accessToken").toString();
		return accessToken;
	}

}
