package com.inma.itp.test.unittest.auth;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.inma.itp.auth.model.dto.UserData;
import com.inma.itp.auth.service.AuthService;
import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.test.TestData;
import com.inma.itp.test.unittest.common.BaseUnitTest;

import lombok.extern.slf4j.Slf4j;
@SpringBootTest
@Slf4j
public class AuthServiceTest extends BaseUnitTest{

	@Autowired
	private AuthService authService;
	
	@Test(timeout = 60000)
	public void loginTest_Success() {
		UserData userData = authService.login(TestData.USERNAME, TestData.PASSWORD);
		assertThat(userData).isNotNull();
		assertThat(userData.getProfile().getId()).isNotBlank();
		log.info("loginTest_Success Test Case Passed : response = " + userData);
	}
	
	@Test(expected = MqException.class)
	public void loginTest_Fail() {
		authService.login(TestData.EMPTY_VALUE, TestData.EMPTY_VALUE);
		log.info("loginTest_Fail Test Case Passed");
	}
}
