package com.inma.itp.test;

public class TestData {
	// Constants
	public final static String SUCCESS_RESPONSE="SUCCESS";
	public final static String FAIL_RESPONSE="FAILS";
	public final static String INVALID_RESPONSE="INVALID";
	public final static String TIMEOUT_RESPONSE="TIMEOUT";


	// Auth Test Data
	public final static String USERNAME ="ITPUAT01";
	public final static String PASSWORD ="Aa_123456";
	public final static String EMPTY_VALUE = "";
	
	// Portfolio Test Data
	public final static String PORTFOLIO_NUMBER = "65519-1";
	public final static String USER_ID = "BKF_USR_1621";
	public final static String POI_NUMBER = "1035527041";
	public final static String STOCK_SYMBOL = "1020";
	
	public final static String INVALID_PORTFOLIO_NUMBER = "9999999999-2-2-1";
	public final static String INVALID_USER_ID = "usr99999999999999999";
	public final static String INVALID_POI_NUMBER = "1035527041999999";
	public final static String INVALID_STOCK_SYMBOL = "ABCD";
	
	// Order Test Data
	public final static String OMS_REF_NUM = "20134S415D";
	public final static String CANCEL_OMS_REF_NUM ="20156JQ27Z";
	public final static String INVALID_OMS_REF_NUM = "999999999999";
 
}
