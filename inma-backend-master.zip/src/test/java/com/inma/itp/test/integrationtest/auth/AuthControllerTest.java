package com.inma.itp.test.integrationtest.auth;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.inma.itp.auth.model.dto.LoginRequest;
import com.inma.itp.test.TestData;
import com.inma.itp.test.integrationtest.common.BaseIntegrationTest;


public class AuthControllerTest extends BaseIntegrationTest{
	private ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
	@Autowired
	private MockMvc mockMvc;

	@Test
	public void signInVerifyStatusResponse() throws Exception {

		LoginRequest request = new LoginRequest();
		request.setUsername(TestData.USERNAME);
		request.setPassword(TestData.PASSWORD);

		mockMvc.perform(post("/api/v1/auth/login").contentType(MediaType.APPLICATION_JSON)
				.content(ow.writeValueAsString(request))).andExpect(status().isOk())
				.andExpect(jsonPath("$.accessToken").exists()).andDo(print());
	}
}
