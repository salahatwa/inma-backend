package com.inma.itp.test.unittest.order;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageSerializerHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.order.dao.OrderDao;
import com.inma.itp.order.model.dto.ETradeOrdDtlsDto;
import com.inma.itp.order.model.messaging.ETradeOrdsInqRq;
import com.inma.itp.order.model.messaging.ETradeOrdsInqRs;
import com.inma.itp.order.service.OrderService;
import com.inma.itp.test.TestData;
import com.inma.itp.test.unittest.common.BaseUnitTest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OrderServiceTest_GetOrderHistory extends BaseUnitTest {
	@Autowired
	private OrderService orderService;
	@MockBean
	private OrderDao orderDao;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	private String getOrderHistoryMockReturnRs;

	@TestConfiguration
	static class OrderServiceTestContextConfiguration {

		@Bean
		public OrderService orderService() {
			return new OrderService();
		}
	}

	@Before
	public void setUp() {
		getOrderHistoryMockSetup();

	}

	private void getOrderHistoryMockSetup() {
		ETradeOrdsInqRq request = new ETradeOrdsInqRq();
		request.setAgentId(TestData.USER_ID);
		request.setOmsRefNum(TestData.OMS_REF_NUM);
		request.setProduct(Constants.PRODUCT);
		request.getRecCtrlIn().setOffset(Constants.OFFSET);
		request.getRecCtrlIn().setMaxRecs(Constants.MAX_RECORDS);
		
		String getOrderHistoryRsStr_Success = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeOrdsInqRs><MsgRsHdr><StatusCode>I000000</StatusCode><RqUID>ITPa71dc6bae0cf498cbf4d641d60fb83e3</RqUID></MsgRsHdr><Body><RecCtrlOut><MatchedRecs>1</MatchedRecs><SentRecs>1</SentRecs></RecCtrlOut><OrdsList><eTradeOrdDtls><OMSRefNum>20183X1HWW</OMSRefNum><MrktCode>Tadawul Main</MrktCode><PortfolioNum>65519-1</PortfolioNum><Symbol>1020</Symbol><SAMAAcctNum>4500012903</SAMAAcctNum><OrdSide>SPR</OrdSide><OrdType>2</OrdType><TIFType>0</TIFType><OrdQty>2</OrdQty><CurAmt><Amt>75</Amt><CurCode>SAR</CurCode></CurAmt><TaxInfo><TaxType>1</TaxType><TaxAmt>0.02</TaxAmt><TaxPercen>15</TaxPercen></TaxInfo><ExcTotalAmt>0</ExcTotalAmt><ExcQty>0</ExcQty><RmnngQty>2</RmnngQty><AvgPrice>0</AvgPrice><OrdCommiss>0.26</OrdCommiss><OrdDt>2020-07-01</OrdDt><OrdTm>12:38:15</OrdTm><OrdDtHjr>2020-07-01</OrdDtHjr><ExpDt>2020-07-01</ExpDt><OrdStatus>NEW</OrdStatus><MrktPrice>75.0</MrktPrice><Broker>10000010</Broker><BankCommiss>0.26</BankCommiss><BrokerCommiss>0.00</BrokerCommiss><TADCommiss>0.08</TADCommiss><CIF>65519</CIF><UsrId>T0450005</UsrId><SCId>ITP</SCId><DealerId>BKF</DealerId></eTradeOrdDtls></OrdsList></Body></eTradeOrdsInqRs>";
		String getOrderHistoryRsStr_Fail = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeOrdsInqRs><MsgRsHdr><StatusCode>E001177</StatusCode><RqUID>ITPa71dc6bae0cf498cbf4d641d60fb83e3</RqUID></MsgRsHdr></eTradeOrdsInqRs>" ;
		ETradeOrdsInqRs getOrderHistoryRs_Success = MessageSerializerHelper
				.deserializeFromXML(getOrderHistoryRsStr_Success, ETradeOrdsInqRs.class);
		ETradeOrdsInqRs getOrderHistoryRs_Fail = MessageSerializerHelper.deserializeFromXML(getOrderHistoryRsStr_Fail,
				ETradeOrdsInqRs.class);
		ETradeOrdsInqRs getOrderHistoryRs_Invalid = new ETradeOrdsInqRs();
		getOrderHistoryRs_Invalid.setStatusCode(Constants.STATUS_CODE_SUCCESS);
		Mockito.when(orderDao.getOrderHistory(request)).thenAnswer(new Answer<Optional<ETradeOrdsInqRs>>() {
			@Override
			public Optional<ETradeOrdsInqRs> answer(InvocationOnMock invocation) {
				if (TestData.SUCCESS_RESPONSE.equals(getOrderHistoryMockReturnRs)) {
					return Optional.ofNullable(getOrderHistoryRs_Success);
				} else if (TestData.FAIL_RESPONSE.equals(getOrderHistoryMockReturnRs)) {
					return Optional.ofNullable(getOrderHistoryRs_Fail);
				} else if (TestData.INVALID_RESPONSE.equals(getOrderHistoryMockReturnRs)) {
					return Optional.ofNullable(getOrderHistoryRs_Invalid);
				} else {
					return Optional.ofNullable(null);
				}

			}
		});
	}

	@Test
	public void getOrderHistory_Success() {
		this.getOrderHistoryMockReturnRs = TestData.SUCCESS_RESPONSE;
		List<ETradeOrdDtlsDto> rs = orderService.getOrderHistory(TestData.USER_ID, TestData.OMS_REF_NUM);
		assertThat(rs).isNotNull();
		assertThat(rs).isNotEmpty();
		log.info("getOrderHistory_Success Test Case Passed : response = " + rs);

	}

	@Test(expected = MqException.class)
	public void getOrderHistory_Fail() {
		this.getOrderHistoryMockReturnRs = TestData.FAIL_RESPONSE;
		orderService.getOrderHistory(TestData.USER_ID, TestData.INVALID_OMS_REF_NUM);
		log.info("getOrderHistory_Fail Test Case Passed");
	}

	@Test
	public void getOrderHistory_Timeout() {
		this.getOrderHistoryMockReturnRs = TestData.TIMEOUT_RESPONSE;
		exceptionRule.expect(MqException.class);
		exceptionRule.expectMessage(Constants.STATUS_CODE_INVALID_RESPONSE);
		orderService.getOrderHistory(TestData.USER_ID, TestData.OMS_REF_NUM);
		log.info("getOrderHistory_Timeout Test Case Passed");
	}

	@Test(expected = ResourceNotFoundException.class)
	public void getOrderHistory_Invalid() {
		this.getOrderHistoryMockReturnRs = TestData.INVALID_RESPONSE;
		orderService.getOrderHistory(TestData.USER_ID, TestData.OMS_REF_NUM);
		log.info("getOrderHistory_Invalid Test Case Passed");
	}

}
