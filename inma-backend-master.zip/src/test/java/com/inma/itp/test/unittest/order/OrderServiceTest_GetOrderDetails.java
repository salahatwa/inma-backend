package com.inma.itp.test.unittest.order;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;

import com.inma.itp.common.exceptions.MqException;
import com.inma.itp.common.exceptions.ResourceNotFoundException;
import com.inma.itp.common.messaging.MessageSerializerHelper;
import com.inma.itp.common.utils.Constants;
import com.inma.itp.order.dao.OrderDao;
import com.inma.itp.order.model.dto.ETradeOrdDtlsDto;
import com.inma.itp.order.model.messaging.ETradeOrdDtlsInqRq;
import com.inma.itp.order.model.messaging.ETradeOrdDtlsInqRs;
import com.inma.itp.order.service.OrderService;
import com.inma.itp.test.TestData;
import com.inma.itp.test.unittest.common.BaseUnitTest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OrderServiceTest_GetOrderDetails extends BaseUnitTest {
	@Autowired
	private OrderService orderService;
	@MockBean
	private OrderDao orderDao;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	private String getOrderDetailsMockReturnRs;

	@TestConfiguration
	static class OrderServiceTestContextConfiguration {

		@Bean
		public OrderService orderService() {
			return new OrderService();
		}
	}

	@Before
	public void setUp() {
		getOrderDetailsMockSetup();

	}

	private void getOrderDetailsMockSetup() {	 
		ETradeOrdDtlsInqRq getOrderDetailsReq = new ETradeOrdDtlsInqRq();
		getOrderDetailsReq.setAgentId(TestData.USER_ID);
		getOrderDetailsReq.setPortfolioNum(TestData.PORTFOLIO_NUMBER);
		getOrderDetailsReq.setOmsRefNum(TestData.OMS_REF_NUM);
		getOrderDetailsReq.setProduct(Constants.PRODUCT);
		String getOrderDetailsRsStr_Success = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeOrdDtlsInqRs><MsgRsHdr><StatusCode>I000000</StatusCode><RqUID>ITPcf241e0133f34c11b79ea6d3068a905f</RqUID></MsgRsHdr><Body><eTradeOrdDtls><MrktCode>510</MrktCode><SAMAAcctNum>4500012903</SAMAAcctNum><Symbol>4150</Symbol><SecShortNameEn>Arriyadh Development Co</SecShortNameEn><SecShortNameAr>???? ?????? ???????</SecShortNameAr><OrdSide>SPR</OrdSide><OrdQty>50</OrdQty><OrdType>2</OrdType><CurAmt><CurCode>SAR</CurCode></CurAmt><RmnngQty>0</RmnngQty><AvgPrice>14</AvgPrice><OrdCommiss>1.09</OrdCommiss><TaxInfo><TaxType>1</TaxType><TaxAmt>0.05</TaxAmt><TaxPercen>5</TaxPercen></TaxInfo><ExcTotalAmt>50</ExcTotalAmt><OrdDt>2020-05-13</OrdDt><OrdStatus>2</OrdStatus></eTradeOrdDtls><RecCtrlOut><MatchedRecs>1</MatchedRecs><SentRecs>1</SentRecs></RecCtrlOut><ExcsList><ExcInfo><TrnRefNum>SCTRSC20134MD4DV</TrnRefNum><ExcDt>2020-05-13T17:25:55</ExcDt><ExcPrice>14</ExcPrice><ExcQty>50</ExcQty><ExcAmt>701.14</ExcAmt><BrokerCommiss>1.09</BrokerCommiss><BankCommiss>0.74</BankCommiss><MrktCommiss>0.35</MrktCommiss><TotalAmt>700.00</TotalAmt><SettlementDt>2020-05-17</SettlementDt><TaxInfo><TaxType>1</TaxType><TaxAmt>0.05</TaxAmt><TaxPercen>5</TaxPercen><InvoiceNum>AIC-VAT20134868037996000</InvoiceNum></TaxInfo></ExcInfo></ExcsList></Body></eTradeOrdDtlsInqRs>";
		String getOrderDetailsRsStr_Fail = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><eTradeOrdDtlsInqRs><MsgRsHdr><StatusCode>E001177</StatusCode><RqUID>ITP988fd1cbdd584f1793db6625dc5804ee</RqUID></MsgRsHdr></eTradeOrdDtlsInqRs>";
		ETradeOrdDtlsInqRs getOrderDetailsRs_Success = MessageSerializerHelper
				.deserializeFromXML(getOrderDetailsRsStr_Success, ETradeOrdDtlsInqRs.class);
		ETradeOrdDtlsInqRs getOrderDetailsRs_Fail = MessageSerializerHelper
				.deserializeFromXML(getOrderDetailsRsStr_Fail, ETradeOrdDtlsInqRs.class);
		ETradeOrdDtlsInqRs getOrderDetailsRs_Invalid = new ETradeOrdDtlsInqRs();
		getOrderDetailsRs_Invalid.setStatusCode(Constants.STATUS_CODE_SUCCESS);
		Mockito.when(orderDao.getOrderDetails(getOrderDetailsReq))
				.thenAnswer(new Answer<Optional<ETradeOrdDtlsInqRs>>() {
					@Override
					public Optional<ETradeOrdDtlsInqRs> answer(InvocationOnMock invocation) {
						if (TestData.SUCCESS_RESPONSE.equals(getOrderDetailsMockReturnRs)) {
							return Optional.ofNullable(getOrderDetailsRs_Success);
						} else if (TestData.FAIL_RESPONSE.equals(getOrderDetailsMockReturnRs)) {
							return Optional.ofNullable(getOrderDetailsRs_Fail);
						} else if (TestData.INVALID_RESPONSE.equals(getOrderDetailsMockReturnRs)) {
							return Optional.ofNullable(getOrderDetailsRs_Invalid);
						} else {
							return Optional.ofNullable(null);
						}

					}
				});
	}

	@Test
	public void getOrderDetails_Success() {
		this.getOrderDetailsMockReturnRs = TestData.SUCCESS_RESPONSE;
		ETradeOrdDtlsDto rs = orderService.getOrderDetails(TestData.USER_ID, TestData.PORTFOLIO_NUMBER,
				TestData.OMS_REF_NUM);
		assertThat(rs).isNotNull();
		assertThat(rs.getOrdStatus()).isNotBlank();
		log.info("getOrderDetails_Success Test Case Passed : response = " + rs);

	}

	@Test(expected = MqException.class)
	public void getOrderDetails_Fail() {
		this.getOrderDetailsMockReturnRs = TestData.FAIL_RESPONSE;
		orderService.getOrderDetails(TestData.USER_ID, TestData.INVALID_PORTFOLIO_NUMBER, TestData.INVALID_OMS_REF_NUM);
		log.info("getOrderDetails_Fail Test Case Passed");
	}

	@Test
	public void getOrderDetails_Timeout() {
		this.getOrderDetailsMockReturnRs = TestData.TIMEOUT_RESPONSE;
		exceptionRule.expect(MqException.class);
		exceptionRule.expectMessage(Constants.STATUS_CODE_INVALID_RESPONSE);
		orderService.getOrderDetails(TestData.USER_ID, TestData.PORTFOLIO_NUMBER, TestData.OMS_REF_NUM);
		log.info("getOrderDetails_Timeout Test Case Passed");
	}

	@Test(expected = ResourceNotFoundException.class)
	public void getOrderDetails_Invalid() {
		this.getOrderDetailsMockReturnRs = TestData.INVALID_RESPONSE;
		orderService.getOrderDetails(TestData.USER_ID, TestData.PORTFOLIO_NUMBER, TestData.OMS_REF_NUM);
		log.info("getOrderDetails_Invalid Test Case Passed");
	}

}
