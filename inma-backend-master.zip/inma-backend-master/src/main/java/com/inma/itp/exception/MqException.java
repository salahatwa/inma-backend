package com.inma.itp.exception;

public class MqException extends RuntimeException{
	public MqException(String message) {
        super(message);
    }

    public MqException(String message, Throwable cause) {
        super(message, cause);
    }
}
