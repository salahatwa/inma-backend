package com.inma.itp.xml;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;

import com.inma.itp.annotation.InmaQueue;

/**
 * Generice Template Service implementation offline equal false send message to
 * queue and received response offline equal true read response from resources
 * 
 * @author ssatwa
 *
 */
@Service
public class MessageTemplateServiceImpl implements MessageTemplateService {
	private static Logger logger = LoggerFactory.getLogger(MessageTemplateService.class);

	@Autowired
	private Requestor requestor;

	@Value("${isOffline}")
	private boolean isOffline;

	@Override
	public <T, R> T sendMessage(R senderObject, Class<T> receivedObject) {
		String rqMsg = MessageSerializerHelper.serializeToXML(senderObject);
		logger.info("Sending message \n{}", rqMsg);
		if (isOffline) {
			T response = MessageSerializerHelper.deserializeFromXML(receivedObject, getFakeRes(senderObject));

			logger.info("Received message \n{}", getFakeRes(senderObject));
			return response;
		} else {
			// Implementation to send message to Queue and get response
			String resp = requestor.request(rqMsg, getQueues(senderObject));
			logger.info("Received message \n{}", getFakeRes(senderObject));
			
			StringUtils.substringBetween(resp, "<StatusCode>", "</StatusCode>");
			T response=MessageSerializerHelper.deserializeFromXML(receivedObject, resp);
			return response;
		}
	}

	/**
	 * 
	 * @param object
	 * @return
	 */
	private String getFakeRes(Object object) {
		try {
			String objectName = object.getClass().getSimpleName();
			String fileName = objectName.substring(0, objectName.length() - 2) + "Rs.xml";

			Resource resource = new ClassPathResource("offline-msg/" + fileName);
			InputStream inputStream = resource.getInputStream();
			byte[] bdata = FileCopyUtils.copyToByteArray(inputStream);
			String xmlMsg = new String(bdata, StandardCharsets.UTF_8);
			return xmlMsg;
		} catch (Exception ex) {
			logger.error("Error File not found {}" + ex.getMessage());
		}
		return null;
	}

	/**
	 * Get Sender and response for Queues name if classes annotated with InmaQueue
	 * Else return sender queue in as class name And return response queue as class
	 * name +'Rs'
	 * 
	 * @param object
	 * @return
	 */
	private String[] getQueues(Object object) {
		String[] classQueues = new String[2];
		try {
			InmaQueue queues = object.getClass().getAnnotation(InmaQueue.class);
			classQueues[0] = queues.requestQueue();
			classQueues[1] = queues.responseQueue();

			return classQueues;
		} catch (Exception ex) {
			classQueues = new String[2];
			String className = object.getClass().getSimpleName();
			classQueues[0] = className;
			classQueues[1] = className.substring(0, className.length() - 2) + "Rs";
			return classQueues;
		}
	}
}
